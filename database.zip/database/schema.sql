-- Galaxy PVC Panels | Neon / PostgreSQL schema
-- All business data remains in PostgreSQL. Product image bytes and generated PDFs are also stored in PostgreSQL.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL,
  description text,
  price numeric(14,2),
  cost_price numeric(14,2),
  quality text,
  stock numeric(14,2) NOT NULL DEFAULT 0,
  low_stock_threshold numeric(14,2) NOT NULL DEFAULT 5,
  unit text NOT NULL DEFAULT 'piece',
  image_url text,
  dimensions text,
  requirements text,
  supplier text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS product_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  content_type text NOT NULL,
  file_name text NOT NULL,
  image_data bytea NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS workers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text,
  role text,
  joining_date date,
  monthly_salary numeric(14,2) NOT NULL DEFAULT 0,
  notes text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS attendance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  worker_id uuid NOT NULL REFERENCES workers(id) ON DELETE CASCADE,
  work_date date NOT NULL,
  status text NOT NULL CHECK (status IN ('present','absent','half_day','leave')),
  hours numeric(5,2) NOT NULL DEFAULT 0,
  work_done text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(worker_id, work_date)
);

CREATE TABLE IF NOT EXISTS worker_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  worker_id uuid NOT NULL REFERENCES workers(id) ON DELETE CASCADE,
  amount numeric(14,2) NOT NULL CHECK(amount >= 0),
  payment_date date NOT NULL DEFAULT current_date,
  payment_type text NOT NULL CHECK(payment_type IN ('salary','advance','bonus','other')),
  month text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS work_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  worker_id uuid NOT NULL REFERENCES workers(id) ON DELETE CASCADE,
  project_id uuid,
  task_date date NOT NULL DEFAULT current_date,
  task text NOT NULL,
  quantity numeric(14,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT 'piece',
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS enquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  phone text NOT NULL,
  category text,
  message text,
  status text NOT NULL DEFAULT 'new' CHECK(status IN ('new','contacted','converted','closed')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  supplier text NOT NULL,
  description text NOT NULL,
  quantity numeric(14,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT 'piece',
  unit_cost numeric(14,2) NOT NULL DEFAULT 0,
  amount numeric(14,2) NOT NULL CHECK(amount >= 0),
  purchase_date date NOT NULL DEFAULT current_date,
  invoice_number text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  expense_date date NOT NULL DEFAULT current_date,
  category text NOT NULL,
  description text NOT NULL,
  amount numeric(14,2) NOT NULL CHECK(amount >= 0),
  payment_mode text DEFAULT 'cash',
  reference text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sales (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sale_date date NOT NULL DEFAULT current_date,
  customer_name text NOT NULL,
  phone text,
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  product_name text NOT NULL,
  quantity numeric(14,2) NOT NULL DEFAULT 1,
  unit text NOT NULL DEFAULT 'piece',
  unit_price numeric(14,2) NOT NULL DEFAULT 0,
  unit_cost numeric(14,2) NOT NULL DEFAULT 0,
  total_amount numeric(14,2) NOT NULL CHECK(total_amount >= 0),
  cost_amount numeric(14,2) NOT NULL DEFAULT 0,
  payment_status text NOT NULL DEFAULT 'paid' CHECK(payment_status IN ('paid','pending','partial')),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  client_name text,
  phone text,
  location text,
  start_date date,
  due_date date,
  status text NOT NULL DEFAULT 'planned' CHECK(status IN ('planned','in_progress','on_hold','completed','cancelled')),
  budget numeric(14,2) NOT NULL DEFAULT 0,
  progress integer NOT NULL DEFAULT 0 CHECK(progress BETWEEN 0 AND 100),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE work_logs DROP CONSTRAINT IF EXISTS work_logs_project_id_fkey;
ALTER TABLE work_logs ADD CONSTRAINT work_logs_project_id_fkey FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE SET NULL;

CREATE TABLE IF NOT EXISTS project_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  worker_id uuid NOT NULL REFERENCES workers(id) ON DELETE CASCADE,
  assigned_role text,
  assigned_on date NOT NULL DEFAULT current_date,
  UNIQUE(project_id, worker_id)
);

CREATE TABLE IF NOT EXISTS quotes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  quote_number text NOT NULL UNIQUE,
  customer_name text NOT NULL,
  phone text,
  address text,
  quote_date date NOT NULL DEFAULT current_date,
  valid_until date,
  items jsonb NOT NULL,
  subtotal numeric(14,2) NOT NULL DEFAULT 0,
  tax_percent numeric(6,2) NOT NULL DEFAULT 0,
  tax_amount numeric(14,2) NOT NULL DEFAULT 0,
  total_amount numeric(14,2) NOT NULL DEFAULT 0,
  notes text,
  pdf_data bytea,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS salary_slips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  worker_id uuid NOT NULL REFERENCES workers(id) ON DELETE CASCADE,
  month text NOT NULL,
  basic_salary numeric(14,2) NOT NULL DEFAULT 0,
  allowances numeric(14,2) NOT NULL DEFAULT 0,
  deductions numeric(14,2) NOT NULL DEFAULT 0,
  net_salary numeric(14,2) NOT NULL DEFAULT 0,
  paid_days numeric(5,2) NOT NULL DEFAULT 0,
  notes text,
  pdf_data bytea,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(worker_id, month)
);

CREATE INDEX IF NOT EXISTS idx_products_active ON products(active);
CREATE INDEX IF NOT EXISTS idx_products_stock ON products(stock, low_stock_threshold);
CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(sale_date);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date);
CREATE INDEX IF NOT EXISTS idx_purchases_date ON purchases(purchase_date);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(work_date);
CREATE INDEX IF NOT EXISTS idx_payments_date ON worker_payments(payment_date);
CREATE INDEX IF NOT EXISTS idx_enquiries_created ON enquiries(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);

-- ---------------------------------------------------------------
-- Website content editor (instant publishing)
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS site_content (
  key text PRIMARY KEY,
  value jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS site_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content_type text NOT NULL,
  file_name text NOT NULL,
  image_data bytea NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE products ADD COLUMN IF NOT EXISTS featured boolean NOT NULL DEFAULT false;
ALTER TABLE products ADD COLUMN IF NOT EXISTS sort_order integer NOT NULL DEFAULT 0;
