import 'dotenv/config';
import express from 'express';
import pg from 'pg';
import multer from 'multer';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {promisify} from 'node:util';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const {Pool} = pg;
const app = express();
const PORT = Number(process.env.PORT || 3001);
const DATABASE_URL = process.env.DATABASE_URL;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const JWT_SECRET = process.env.JWT_SECRET;
const scrypt = promisify(crypto.scrypt);

if (!DATABASE_URL) console.warn('DATABASE_URL is missing. Add your Neon PostgreSQL connection string to .env.');
if (!ADMIN_PASSWORD) console.warn('ADMIN_PASSWORD is missing. Admin login will be disabled until it is set.');
if (!JWT_SECRET || JWT_SECRET.length < 32) console.warn('JWT_SECRET should be a random secret with at least 32 characters.');

const pool = DATABASE_URL ? new Pool({
  connectionString: DATABASE_URL,
  ssl: process.env.DATABASE_SSL === 'disable' ? false : {rejectUnauthorized: false},
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 12000,
  statement_timeout: 30000,
  application_name: 'galaxy-pvc-panels'
}) : null;

app.disable('x-powered-by');
app.use(express.json({limit: '2mb'}));
const upload = multer({storage: multer.memoryStorage(), limits: {fileSize: 8 * 1024 * 1024}, fileFilter: (_req, file, cb) => {
  if (!['image/jpeg','image/png','image/webp','image/avif'].includes(file.mimetype)) return cb(new Error('Upload a JPG, PNG, WEBP or AVIF image.'));
  cb(null, true);
}});

const publicDir = path.join(ROOT, 'dist');
const schemaPath = path.join(ROOT, 'database', 'schema.sql');
let dbReady = false;
async function initializeDatabase() {
  if (!pool) return;
  const schema = fs.readFileSync(schemaPath, 'utf8');
  await pool.query(schema);
  dbReady = true;
  await seedDefaults();
  console.log('PostgreSQL schema checked and ready.');
}

const SEED_PRODUCTS = [
  {name:'Fluted PVC Panels', category:'PVC Wall Panels', price:350, image:'/assets/seed/fluted-pvc-panels.jpg', description:'Premium fluted PVC wall panels with a warm wood-look finish. Waterproof, termite resistant and easy to install - ideal for TV units and feature walls.'},
  {name:'PVC Wall Panels', category:'PVC Wall Panels', price:320, image:'/assets/seed/pvc-wall-panels.jpg', description:'Marble-look PVC wall panels for a clean, luxurious interior. Low maintenance and long lasting.'},
  {name:'PVC Ceiling Panels', category:'PVC Ceiling Panels', price:300, image:'/assets/seed/pvc-ceiling-panels.jpg', description:'Elegant PVC ceiling panels that work beautifully with cove and concealed lighting.'},
  {name:'Charcoal Panels', category:'Charcoal Panels', price:370, image:'/assets/seed/charcoal-panels.jpg', description:'Deep charcoal fluted panels for a bold, modern statement wall.'}
];
async function seedDefaults() {
  // Runs once. Adds the four sample products from the design so the catalogue is not empty; admin can edit or delete them.
  const done = await pool.query("SELECT 1 FROM site_content WHERE key='seeded'");
  if (done.rowCount) return;
  const count = await pool.query('SELECT COUNT(*)::int AS n FROM products');
  if (count.rows[0].n === 0) {
    for (const [i, p] of SEED_PRODUCTS.entries()) {
      await pool.query('INSERT INTO products(name,category,description,price,unit,image_url,quality,stock,low_stock_threshold,featured,sort_order,active) VALUES($1,$2,$3,$4,$5,$6,$7,0,5,true,$8,true)',
        [p.name, p.category, p.description, p.price, 'sq.ft', p.image, 'Premium', i + 1]);
    }
  }
  await pool.query("INSERT INTO site_content(key,value) VALUES('seeded','true'::jsonb) ON CONFLICT DO NOTHING");
}
function ensureDb(_req, res, next) {
  if (!pool || !dbReady) return res.status(503).json({error: 'PostgreSQL is not connected. Configure DATABASE_URL and restart the server.'});
  next();
}

function b64url(input) { return Buffer.from(input).toString('base64url'); }
function signToken(payload) {
  const body = b64url(JSON.stringify(payload));
  const signature = crypto.createHmac('sha256', JWT_SECRET).update(body).digest('base64url');
  return `${body}.${signature}`;
}
function verifyToken(token) {
  if (!JWT_SECRET || !token) return null;
  const [body, signature] = token.split('.');
  if (!body || !signature) return null;
  const expected = crypto.createHmac('sha256', JWT_SECRET).update(body).digest();
  let actual;
  try { actual = Buffer.from(signature, 'base64url'); } catch { return null; }
  if (actual.length !== expected.length || !crypto.timingSafeEqual(actual, expected)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (!payload.exp || payload.exp < Math.floor(Date.now()/1000)) return null;
    return payload;
  } catch { return null; }
}
function requireAdmin(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const payload = verifyToken(token);
  if (!payload?.admin) return res.status(401).json({error: 'Admin session expired. Please sign in again.'});
  req.admin = payload;
  next();
}
function safeText(value, max=5000) { return String(value ?? '').trim().slice(0, max); }
function number(value, fallback=0) { const n = Number(value); return Number.isFinite(n) ? n : fallback; }
const tableConfig = {
  products: {fields:['name','category','description','price','cost_price','quality','stock','low_stock_threshold','unit','image_url','dimensions','requirements','supplier','featured','sort_order','active'], order:'created_at DESC'},
  workers: {fields:['name','phone','role','joining_date','monthly_salary','notes','active'], order:'created_at DESC'},
  attendance: {fields:['worker_id','work_date','status','hours','work_done','notes'], order:'work_date DESC'},
  worker_payments: {fields:['worker_id','amount','payment_date','payment_type','month','notes'], order:'payment_date DESC'},
  work_logs: {fields:['worker_id','project_id','task_date','task','quantity','unit','notes'], order:'task_date DESC'},
  enquiries: {fields:['customer_name','phone','category','message','status'], order:'created_at DESC'},
  purchases: {fields:['product_id','supplier','description','quantity','unit','unit_cost','amount','purchase_date','invoice_number','notes'], order:'purchase_date DESC'},
  expenses: {fields:['expense_date','category','description','amount','payment_mode','reference','notes'], order:'expense_date DESC'},
  sales: {fields:['sale_date','customer_name','phone','product_id','product_name','quantity','unit','unit_price','unit_cost','total_amount','cost_amount','payment_status','notes'], order:'sale_date DESC'},
  projects: {fields:['name','client_name','phone','location','start_date','due_date','status','budget','progress','notes'], order:'created_at DESC'},
  project_assignments: {fields:['project_id','worker_id','assigned_role','assigned_on'], order:'assigned_on DESC'}
};
function pickFields(body, fields) {
  const row = {};
  for (const field of fields) if (Object.hasOwn(body || {}, field)) row[field] = body[field] === '' ? null : body[field];
  return row;
}
async function queryRows(table, limit=500) {
  const config = tableConfig[table];
  if (!config) throw new Error('Unsupported data table.');
  const result = await pool.query(`SELECT * FROM ${table} ORDER BY ${config.order} LIMIT $1`, [limit]);
  return result.rows;
}

// Small dependency-free PDF writer. It produces simple, printable A4 documents.
function pdfEscape(value) { return String(value ?? '').replace(/[^\x20-\x7E]/g, '?').replace(/\\/g,'\\\\').replace(/\(/g,'\\(').replace(/\)/g,'\\)'); }
function makePdf(title, lines) {
  const content = ['BT','/F1 18 Tf','48 790 Td',`(${pdfEscape(title)}) Tj`,'/F1 10 Tf'];
  let y = 760;
  for (const line of lines) {
    if (y < 55) break;
    const chunks = String(line ?? '').match(/.{1,92}(\s|$)/g) || [String(line ?? '')];
    for (const chunk of chunks) {
      if (y < 55) break;
      content.push(`1 0 0 1 48 ${y} Tm (${pdfEscape(chunk.trim())}) Tj`);
      y -= 16;
    }
  }
  content.push('ET');
  const stream = content.join('\n');
  const objects = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
    `<< /Length ${Buffer.byteLength(stream)} >>\nstream\n${stream}\nendstream`
  ];
  let pdf = '%PDF-1.4\n';
  const offsets = [0];
  objects.forEach((obj, i) => { offsets.push(Buffer.byteLength(pdf)); pdf += `${i+1} 0 obj\n${obj}\nendobj\n`; });
  const xref = Buffer.byteLength(pdf);
  pdf += `xref\n0 ${objects.length+1}\n0000000000 65535 f \n`;
  for (let i=1;i<offsets.length;i++) pdf += `${String(offsets[i]).padStart(10,'0')} 00000 n \n`;
  pdf += `trailer\n<< /Size ${objects.length+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return Buffer.from(pdf, 'binary');
}
function sendPdf(res, data, filename) {
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${filename.replace(/[^a-zA-Z0-9_.-]/g,'_')}"`);
  res.setHeader('Cache-Control', 'private, no-store');
  res.send(data);
}

app.get('/api/health', async (_req, res) => {
  let database = 'not_configured';
  if (pool && dbReady) {
    try { await pool.query('SELECT 1'); database = 'connected'; } catch { database = 'error'; }
  }
  res.json({ok: true, database, adminConfigured: Boolean(ADMIN_PASSWORD && JWT_SECRET?.length >= 32)});
});

const loginAttempts = new Map();
app.post('/api/login', ensureDb, async (req, res) => {
  const address = req.ip || req.socket.remoteAddress || 'local';
  const now = Date.now();
  const entry = loginAttempts.get(address) || {count:0, start:now};
  if (now-entry.start > 10*60*1000) { entry.count=0; entry.start=now; }
  if (entry.count >= 8) return res.status(429).json({error:'Too many login attempts. Try again after 10 minutes.'});
  entry.count++; loginAttempts.set(address, entry);
  if (!ADMIN_PASSWORD || !JWT_SECRET || JWT_SECRET.length < 32) return res.status(503).json({error:'Set ADMIN_PASSWORD and a 32+ character JWT_SECRET in the server environment.'});
  const supplied = String(req.body?.password || '');
  const salt = crypto.createHash('sha256').update('galaxy-pvc-panels-admin-v1').digest();
  const [expected, actual] = await Promise.all([scrypt(ADMIN_PASSWORD, salt, 64), scrypt(supplied, salt, 64)]);
  if (!crypto.timingSafeEqual(expected, actual)) return res.status(401).json({error:'Incorrect password. Please try again.'});
  loginAttempts.delete(address);
  const token = signToken({admin:true, sub:'galaxy-admin', iat:Math.floor(now/1000), exp:Math.floor(now/1000)+12*60*60});
  res.json({token, expiresIn:43200});
});
app.get('/api/me', requireAdmin, (_req, res) => res.json({admin:true, name:'Administrator'}));

app.get('/api/public/products', ensureDb, async (_req, res, next) => {
  try { const {rows} = await pool.query('SELECT id,name,category,description,price,quality,stock,unit,image_url,dimensions,featured,sort_order FROM products WHERE active=true ORDER BY featured DESC, sort_order ASC, created_at DESC'); res.json(rows); }
  catch (error) { next(error); }
});
app.post('/api/public/enquiries', ensureDb, async (req, res, next) => {
  try {
    const name=safeText(req.body?.customer_name,120), phone=safeText(req.body?.phone,40);
    if (!name || !phone) return res.status(400).json({error:'Name and phone are required.'});
    const {rows} = await pool.query('INSERT INTO enquiries(customer_name,phone,category,message) VALUES($1,$2,$3,$4) RETURNING id', [name,phone,safeText(req.body?.category,120)||null,safeText(req.body?.message,2000)||null]);
    res.status(201).json({ok:true,id:rows[0].id});
  } catch(error) { next(error); }
});
app.get('/api/product-images/:id', ensureDb, async (req,res,next)=>{
  try { const {rows}=await pool.query('SELECT content_type,image_data FROM product_images WHERE id=$1',[req.params.id]); if(!rows.length)return res.sendStatus(404); res.setHeader('Content-Type',rows[0].content_type);res.setHeader('Cache-Control','public,max-age=86400');res.send(rows[0].image_data); }
  catch(error){next(error);}
});


// ---------- Website content (public read, admin write) ----------
const SITE_KEY = 'site';
const siteImageUpload = multer({storage: multer.memoryStorage(), limits: {fileSize: 8 * 1024 * 1024}, fileFilter: (_req, file, cb) => {
  if (!['image/jpeg','image/png','image/webp','image/avif','image/svg+xml'].includes(file.mimetype)) return cb(new Error('Upload a JPG, PNG, WEBP, AVIF or SVG image.'));
  cb(null, true);
}});
function collectSiteImageIds(value, ids=new Set()) {
  if (typeof value === 'string') { for (const m of value.matchAll(/\/api\/site-images\/([0-9a-f-]{36})/gi)) ids.add(m[1].toLowerCase()); }
  else if (Array.isArray(value)) value.forEach(v => collectSiteImageIds(v, ids));
  else if (value && typeof value === 'object') Object.values(value).forEach(v => collectSiteImageIds(v, ids));
  return ids;
}
app.get('/api/public/site', ensureDb, async (_req, res, next) => {
  try {
    const {rows} = await pool.query('SELECT value FROM site_content WHERE key=$1', [SITE_KEY]);
    res.setHeader('Cache-Control', 'no-store');
    res.json(rows[0]?.value || {});
  } catch (error) { next(error); }
});
app.get('/api/site-images/:id', ensureDb, async (req, res, next) => {
  try {
    if (!/^[0-9a-f-]{36}$/i.test(req.params.id)) return res.sendStatus(404);
    const {rows} = await pool.query('SELECT content_type,image_data FROM site_images WHERE id=$1', [req.params.id]);
    if (!rows.length) return res.sendStatus(404);
    res.setHeader('Content-Type', rows[0].content_type);
    res.setHeader('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'");
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'public,max-age=31536000,immutable');
    res.send(rows[0].image_data);
  } catch (error) { next(error); }
});
app.get('/api/admin/site', ensureDb, requireAdmin, async (_req, res, next) => {
  try {
    const {rows} = await pool.query('SELECT value, updated_at FROM site_content WHERE key=$1', [SITE_KEY]);
    res.json({content: rows[0]?.value || {}, updated_at: rows[0]?.updated_at || null});
  } catch (error) { next(error); }
});
app.put('/api/admin/site', ensureDb, requireAdmin, async (req, res, next) => {
  try {
    const content = req.body?.content;
    if (!content || typeof content !== 'object' || Array.isArray(content)) return res.status(400).json({error: 'Website content is missing or invalid.'});
    const json = JSON.stringify(content);
    if (Buffer.byteLength(json) > 600 * 1024) return res.status(413).json({error: 'Website content is too large.'});
    const {rows} = await pool.query(
      `INSERT INTO site_content(key,value,updated_at) VALUES($1,$2::jsonb,now())
       ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value, updated_at=now() RETURNING updated_at`, [SITE_KEY, json]);
    // Tidy up uploaded images that are no longer used anywhere (keeps recent uploads for 1 day).
    const used = [...collectSiteImageIds(content)];
    await pool.query(`DELETE FROM site_images WHERE created_at < now() - interval '1 day' AND NOT (id::text = ANY($1::text[]))`, [used]);
    res.json({ok: true, updated_at: rows[0].updated_at});
  } catch (error) { next(error); }
});
app.post('/api/admin/site/image', ensureDb, requireAdmin, siteImageUpload.single('image'), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({error: 'Choose an image first.'});
    const {rows} = await pool.query('INSERT INTO site_images(content_type,file_name,image_data) VALUES($1,$2,$3) RETURNING id', [req.file.mimetype, safeText(req.file.originalname, 180), req.file.buffer]);
    res.status(201).json({url: `/api/site-images/${rows[0].id}`});
  } catch (error) { next(error); }
});

app.get('/api/admin/data', ensureDb, requireAdmin, async (_req,res,next)=>{
  try {
    const names=Object.keys(tableConfig);
    const values=await Promise.all(names.map(name=>queryRows(name,500)));
    const data=Object.fromEntries(names.map((name,i)=>[name,values[i]]));
    const slips=await pool.query('SELECT s.id,s.worker_id,w.name AS worker_name,s.month,s.basic_salary,s.allowances,s.deductions,s.net_salary,s.paid_days,s.created_at FROM salary_slips s JOIN workers w ON w.id=s.worker_id ORDER BY s.month DESC LIMIT 200');
    const quotes=await pool.query('SELECT id,quote_number,customer_name,phone,quote_date,valid_until,total_amount,created_at FROM quotes ORDER BY created_at DESC LIMIT 200');
    data.salary_slips=slips.rows; data.quotes=quotes.rows;
    res.json(data);
  } catch(error){next(error);}
});

app.get('/api/admin/reports/monthly', ensureDb, requireAdmin, async (req,res,next)=>{
  try {
    const month=/^\d{4}-\d{2}$/.test(req.query.month||'')?req.query.month:new Date().toISOString().slice(0,7);
    const [sales,expenses,salaries,purchases] = await Promise.all([
      pool.query("SELECT COALESCE(SUM(total_amount),0) AS revenue,COALESCE(SUM(cost_amount),0) AS cogs,COUNT(*)::int AS invoices FROM sales WHERE to_char(sale_date,'YYYY-MM')=$1",[month]),
      pool.query("SELECT COALESCE(SUM(amount),0) AS total,COUNT(*)::int AS count FROM expenses WHERE to_char(expense_date,'YYYY-MM')=$1",[month]),
      pool.query("SELECT COALESCE(SUM(amount),0) AS total FROM worker_payments WHERE to_char(payment_date,'YYYY-MM')=$1 AND payment_type IN ('salary','bonus')",[month]),
      pool.query("SELECT COALESCE(SUM(amount),0) AS total FROM purchases WHERE to_char(purchase_date,'YYYY-MM')=$1",[month])
    ]);
    const revenue=number(sales.rows[0].revenue),cogs=number(sales.rows[0].cogs),expenseTotal=number(expenses.rows[0].total),salaryTotal=number(salaries.rows[0].total);
    res.json({month,revenue,cogs,gross_profit:revenue-cogs,expenses:expenseTotal,salary_expense:salaryTotal,net_profit:revenue-cogs-expenseTotal-salaryTotal,invoice_count:sales.rows[0].invoices,purchase_total:number(purchases.rows[0].total),expense_count:expenses.rows[0].count});
  } catch(error){next(error);}
});
app.get('/api/admin/analytics', ensureDb, requireAdmin, async (_req,res,next)=>{
  try {
    const {rows}=await pool.query(`SELECT to_char(date_trunc('month',sale_date),'YYYY-MM') AS month,COALESCE(SUM(total_amount),0) AS sales,COUNT(*)::int AS invoices FROM sales WHERE sale_date>=date_trunc('month',current_date)-interval '11 months' GROUP BY 1 ORDER BY 1`);
    const {rows:top}=await pool.query('SELECT product_name,COALESCE(SUM(quantity),0) AS quantity,COALESCE(SUM(total_amount),0) AS revenue FROM sales GROUP BY product_name ORDER BY revenue DESC LIMIT 5');
    res.json({monthly:rows,top_products:top});
  } catch(error){next(error);}
});
app.get('/api/admin/low-stock', ensureDb, requireAdmin, async (_req,res,next)=>{
  try { const {rows}=await pool.query('SELECT id,name,category,stock,unit,low_stock_threshold FROM products WHERE active=true AND stock<=low_stock_threshold ORDER BY stock ASC');res.json(rows); }
  catch(error){next(error);}
});

app.get('/api/admin/:table', ensureDb, requireAdmin, async(req,res,next)=>{
  try { const rows=await queryRows(req.params.table,1000);res.json(rows); }
  catch(error){ if(error.message==='Unsupported data table.')return res.status(404).json({error:error.message});next(error); }
});
app.post('/api/admin/sales', ensureDb, requireAdmin, async(req,res,next)=>{
  const body=req.body||{};
  const qty=number(body.quantity,1), unitPrice=number(body.unit_price), unitCost=number(body.unit_cost);
  if(qty<=0||unitPrice<0||unitCost<0||!safeText(body.customer_name,120)||!safeText(body.product_name,180))return res.status(400).json({error:'Customer, product and a positive quantity are required.'});
  const client=await pool.connect();
  try {
    await client.query('BEGIN');
    if(body.product_id){const stock=await client.query('SELECT stock FROM products WHERE id=$1 FOR UPDATE',[body.product_id]);if(!stock.rowCount)throw new Error('Selected product was not found.');if(number(stock.rows[0].stock)<qty)throw new Error('Not enough stock for this sale. Update stock or choose a smaller quantity.');await client.query('UPDATE products SET stock=stock-$1 WHERE id=$2',[qty,body.product_id]);}
    const payload=pickFields(body,tableConfig.sales.fields);payload.quantity=qty;payload.unit_price=unitPrice;payload.unit_cost=unitCost;payload.total_amount=qty*unitPrice;payload.cost_amount=qty*unitCost;
    const keys=Object.keys(payload);const {rows}=await client.query(`INSERT INTO sales(${keys.join(',')}) VALUES(${keys.map((_,i)=>`$${i+1}`).join(',')}) RETURNING *`,keys.map(k=>payload[k]));
    await client.query('COMMIT');res.status(201).json(rows[0]);
  }catch(error){await client.query('ROLLBACK');res.status(400).json({error:error.message});}
  finally{client.release();}
});
app.post('/api/admin/purchases', ensureDb, requireAdmin, async(req,res,next)=>{
  const body=req.body||{},qty=number(body.quantity),unitCost=number(body.unit_cost),amount=number(body.amount,qty*unitCost);
  if(qty<0||unitCost<0||!safeText(body.supplier,120)||!safeText(body.description,500)||amount<0)return res.status(400).json({error:'Supplier, description and a valid amount are required.'});
  const client=await pool.connect();
  try {
    await client.query('BEGIN');
    if(body.product_id&&qty>0){const found=await client.query('SELECT id FROM products WHERE id=$1 FOR UPDATE',[body.product_id]);if(!found.rowCount)throw new Error('Selected product was not found.');await client.query('UPDATE products SET stock=stock+$1 WHERE id=$2',[qty,body.product_id]);}
    const payload=pickFields(body,tableConfig.purchases.fields);payload.quantity=qty;payload.unit_cost=unitCost;payload.amount=amount;const keys=Object.keys(payload);
    const {rows}=await client.query(`INSERT INTO purchases(${keys.join(',')}) VALUES(${keys.map((_,i)=>`$${i+1}`).join(',')}) RETURNING *`,keys.map(k=>payload[k]));
    await client.query('COMMIT');res.status(201).json(rows[0]);
  }catch(error){await client.query('ROLLBACK');res.status(400).json({error:error.message});}
  finally{client.release();}
});

app.post('/api/admin/:table', ensureDb, requireAdmin, async(req,res,next)=>{
  const table=req.params.table, config=tableConfig[table];
  if(!config)return res.status(404).json({error:'Unsupported data table.'});
  try {
    const row=pickFields(req.body,config.fields), keys=Object.keys(row);
    if(!keys.length)return res.status(400).json({error:'No valid fields supplied.'});
    const cols=keys.map(k=>`"${k}"`).join(','),vals=keys.map((_,i)=>`$${i+1}`).join(',');
    const {rows}=await pool.query(`INSERT INTO ${table} (${cols}) VALUES (${vals}) RETURNING *`,keys.map(k=>row[k]));
    res.status(201).json(rows[0]);
  }catch(error){next(error);}
});
app.patch('/api/admin/sales/:id', ensureDb, requireAdmin, async(req,res,next)=>{
  const client=await pool.connect();
  try {
    await client.query('BEGIN');
    const body=req.body||{};const oldResult=await client.query('SELECT * FROM sales WHERE id=$1 FOR UPDATE',[req.params.id]);
    if(!oldResult.rowCount){await client.query('ROLLBACK');return res.sendStatus(404);}const old=oldResult.rows[0];
    const row=pickFields(body,tableConfig.sales.fields);const oldQty=number(old.quantity),newQty=number(row.quantity,oldQty);
    const oldProduct=old.product_id||null,newProduct=Object.hasOwn(row,'product_id')?(row.product_id||null):oldProduct;
    if(oldProduct && oldProduct===newProduct){
      const delta=newQty-oldQty;const stock=await client.query('SELECT stock FROM products WHERE id=$1 FOR UPDATE',[oldProduct]);
      if(!stock.rowCount)throw new Error('Selected product was not found.');
      if(delta>0&&number(stock.rows[0].stock)<delta)throw new Error('Not enough stock for the increased sale quantity.');
      if(delta!==0)await client.query('UPDATE products SET stock=stock-$1 WHERE id=$2',[delta,oldProduct]);
    } else {
      if(oldProduct)await client.query('UPDATE products SET stock=stock+$1 WHERE id=$2',[oldQty,oldProduct]);
      if(newProduct){const stock=await client.query('SELECT stock FROM products WHERE id=$1 FOR UPDATE',[newProduct]);if(!stock.rowCount)throw new Error('Selected product was not found.');if(number(stock.rows[0].stock)<newQty)throw new Error('Not enough stock for this sale.');await client.query('UPDATE products SET stock=stock-$1 WHERE id=$2',[newQty,newProduct]);}
    }
    row.total_amount=newQty*number(row.unit_price,number(old.unit_price));row.cost_amount=newQty*number(row.unit_cost,number(old.unit_cost));
    const keys=Object.keys(row);const set=keys.map((k,i)=>`"${k}"=$${i+1}`).join(',');
    const {rows}=await client.query(`UPDATE sales SET ${set} WHERE id=$${keys.length+1} RETURNING *`,[...keys.map(k=>row[k]),req.params.id]);
    await client.query('COMMIT');res.json(rows[0]);
  }catch(error){await client.query('ROLLBACK');res.status(400).json({error:error.message});}
  finally{client.release();}
});
app.patch('/api/admin/purchases/:id', ensureDb, requireAdmin, async(req,res,next)=>{
  const client=await pool.connect();
  try {
    await client.query('BEGIN');
    const body=req.body||{};const oldResult=await client.query('SELECT * FROM purchases WHERE id=$1 FOR UPDATE',[req.params.id]);
    if(!oldResult.rowCount){await client.query('ROLLBACK');return res.sendStatus(404);}const old=oldResult.rows[0];const row=pickFields(body,tableConfig.purchases.fields);
    const oldProduct=old.product_id||null,newProduct=Object.hasOwn(row,'product_id')?(row.product_id||null):oldProduct;
    const oldQty=number(old.quantity),newQty=number(row.quantity,oldQty);
    if(oldProduct && oldProduct===newProduct){
      const delta=newQty-oldQty;const stock=await client.query('SELECT stock FROM products WHERE id=$1 FOR UPDATE',[oldProduct]);
      if(!stock.rowCount)throw new Error('Selected product was not found.');
      if(delta<0&&number(stock.rows[0].stock)<(-delta))throw new Error('Cannot reduce this purchase quantity: some of the purchased stock has already been used.');
      if(delta!==0)await client.query('UPDATE products SET stock=stock+$1 WHERE id=$2',[delta,oldProduct]);
    } else {
      if(oldProduct){const oldStock=await client.query('SELECT stock FROM products WHERE id=$1 FOR UPDATE',[oldProduct]);if(!oldStock.rowCount||number(oldStock.rows[0].stock)<oldQty)throw new Error('Cannot unlink this purchase: some of the purchased stock has already been used.');await client.query('UPDATE products SET stock=stock-$1 WHERE id=$2',[oldQty,oldProduct]);}
      if(newProduct){const found=await client.query('SELECT id FROM products WHERE id=$1 FOR UPDATE',[newProduct]);if(!found.rowCount)throw new Error('Selected product was not found.');await client.query('UPDATE products SET stock=stock+$1 WHERE id=$2',[newQty,newProduct]);}
    }
    const keys=Object.keys(row);const set=keys.map((k,i)=>`"${k}"=$${i+1}`).join(',');
    const {rows}=await client.query(`UPDATE purchases SET ${set} WHERE id=$${keys.length+1} RETURNING *`,[...keys.map(k=>row[k]),req.params.id]);
    await client.query('COMMIT');res.json(rows[0]);
  }catch(error){await client.query('ROLLBACK');res.status(400).json({error:error.message});}
  finally{client.release();}
});
app.patch('/api/admin/:table/:id', ensureDb, requireAdmin, async(req,res,next)=>{
  const table=req.params.table, config=tableConfig[table];
  if(!config)return res.status(404).json({error:'Unsupported data table.'});
  try {
    const row=pickFields(req.body,config.fields), keys=Object.keys(row);
    if(!keys.length)return res.status(400).json({error:'No valid fields supplied.'});
    const set=keys.map((k,i)=>`"${k}"=$${i+1}`).join(',');
    const {rows}=await pool.query(`UPDATE ${table} SET ${set} WHERE id=$${keys.length+1} RETURNING *`,[...keys.map(k=>row[k]),req.params.id]);
    if(!rows.length)return res.sendStatus(404);res.json(rows[0]);
  }catch(error){next(error);}
});
app.delete('/api/admin/sales/:id', ensureDb, requireAdmin, async(req,res,next)=>{
  const client=await pool.connect();
  try {
    await client.query('BEGIN');
    const {rows}=await client.query('SELECT product_id,quantity FROM sales WHERE id=$1 FOR UPDATE',[req.params.id]);
    if(!rows.length){await client.query('ROLLBACK');return res.sendStatus(404);}
    if(rows[0].product_id)await client.query('UPDATE products SET stock=stock+$1 WHERE id=$2',[number(rows[0].quantity),rows[0].product_id]);
    await client.query('DELETE FROM sales WHERE id=$1',[req.params.id]);
    await client.query('COMMIT');res.json({deleted:1});
  }catch(error){await client.query('ROLLBACK');res.status(400).json({error:error.message});}
  finally{client.release();}
});
app.delete('/api/admin/purchases/:id', ensureDb, requireAdmin, async(req,res,next)=>{
  const client=await pool.connect();
  try {
    await client.query('BEGIN');
    const {rows}=await client.query('SELECT product_id,quantity FROM purchases WHERE id=$1 FOR UPDATE',[req.params.id]);
    if(!rows.length){await client.query('ROLLBACK');return res.sendStatus(404);}
    if(rows[0].product_id){const stock=await client.query('SELECT stock FROM products WHERE id=$1 FOR UPDATE',[rows[0].product_id]);if(!stock.rowCount||number(stock.rows[0].stock)<number(rows[0].quantity))throw new Error('Cannot delete this purchase: some of the purchased stock has already been used.');await client.query('UPDATE products SET stock=stock-$1 WHERE id=$2',[number(rows[0].quantity),rows[0].product_id]);}
    await client.query('DELETE FROM purchases WHERE id=$1',[req.params.id]);
    await client.query('COMMIT');res.json({deleted:1});
  }catch(error){await client.query('ROLLBACK');res.status(400).json({error:error.message});}
  finally{client.release();}
});
app.delete('/api/admin/:table/:id', ensureDb, requireAdmin, async(req,res,next)=>{
  const table=req.params.table;if(!tableConfig[table])return res.status(404).json({error:'Unsupported data table.'});
  try {const result=await pool.query(`DELETE FROM ${table} WHERE id=$1`,[req.params.id]);res.json({deleted:result.rowCount});}
  catch(error){next(error);}
});

app.post('/api/admin/products/:id/image', ensureDb, requireAdmin, upload.single('image'), async(req,res,next)=>{
  const client=await pool.connect();
  try {
    if(!req.file)return res.status(400).json({error:'Choose a product image first.'});
    await client.query('BEGIN');
    const exists=await client.query('SELECT image_url FROM products WHERE id=$1 FOR UPDATE',[req.params.id]);
    if(!exists.rowCount){await client.query('ROLLBACK');return res.sendStatus(404);}
    const {rows}=await client.query('INSERT INTO product_images(product_id,content_type,file_name,image_data) VALUES($1,$2,$3,$4) RETURNING id',[req.params.id,req.file.mimetype,safeText(req.file.originalname,180),req.file.buffer]);
    const imageUrl=`/api/product-images/${rows[0].id}`;
    await client.query('UPDATE products SET image_url=$1 WHERE id=$2',[imageUrl,req.params.id]);
    const previous=String(exists.rows[0].image_url||'').match(/^\/api\/product-images\/([0-9a-f-]+)$/i);
    if(previous)await client.query('DELETE FROM product_images WHERE id=$1',[previous[1]]);
    await client.query('COMMIT');res.status(201).json({image_url:imageUrl});
  }catch(error){await client.query('ROLLBACK');next(error);}
  finally{client.release();}
});

app.post('/api/admin/quotes/pdf', ensureDb, requireAdmin, async(req,res,next)=>{
  try {
    const b=req.body||{},items=Array.isArray(b.items)?b.items.slice(0,50):[];
    if(!safeText(b.customer_name,120)||!items.length)return res.status(400).json({error:'Customer name and at least one quotation item are required.'});
    const subtotal=items.reduce((s,item)=>s+number(item.quantity)*number(item.rate),0),taxPercent=Math.max(0,Math.min(100,number(b.tax_percent))),taxAmount=subtotal*taxPercent/100,total=subtotal+taxAmount;
    const quoteNumber=`GQP-${new Date().getFullYear()}-${Date.now().toString().slice(-7)}`;
    const lines=['Galaxy PVC Panels','Kalewadi, Pimpri-Chinchwad, Maharashtra 411017 | +91 95279 29796 / +91 89751 01040','',`Quote No: ${quoteNumber}`,`Date: ${b.quote_date||new Date().toISOString().slice(0,10)}`,`Customer: ${safeText(b.customer_name,120)}`,`Phone: ${safeText(b.phone,40)}`,`Address: ${safeText(b.address,250)}`,'','DESCRIPTION | QTY | RATE | AMOUNT',...items.map(i=>`${safeText(i.name,80)} | ${number(i.quantity)} ${safeText(i.unit,20)} | Rs ${number(i.rate).toFixed(2)} | Rs ${(number(i.quantity)*number(i.rate)).toFixed(2)}`),'',`Subtotal: Rs ${subtotal.toFixed(2)}`,`Tax (${taxPercent}%): Rs ${taxAmount.toFixed(2)}`,`GRAND TOTAL: Rs ${total.toFixed(2)}`,'',`Valid until: ${safeText(b.valid_until,30)}`,`Notes: ${safeText(b.notes,500)}`,'','Thank you for considering Galaxy PVC Panels.'];
    const pdf=makePdf('CUSTOMER QUOTATION',lines);
    const {rows}=await pool.query('INSERT INTO quotes(quote_number,customer_name,phone,address,quote_date,valid_until,items,subtotal,tax_percent,tax_amount,total_amount,notes,pdf_data) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING id,quote_number,total_amount',[quoteNumber,safeText(b.customer_name,120),safeText(b.phone,40)||null,safeText(b.address,250)||null,b.quote_date||new Date().toISOString().slice(0,10),b.valid_until||null,JSON.stringify(items),subtotal,taxPercent,taxAmount,total,safeText(b.notes,1000)||null,pdf]);
    res.json({id:rows[0].id,quote_number:rows[0].quote_number,total_amount:rows[0].total_amount,pdf:pdf.toString('base64'),filename:`${quoteNumber}.pdf`});
  }catch(error){next(error);}
});
app.get('/api/admin/quotes/:id/pdf', ensureDb, requireAdmin, async(req,res,next)=>{
  try {const {rows}=await pool.query('SELECT quote_number,pdf_data FROM quotes WHERE id=$1',[req.params.id]);if(!rows.length||!rows[0].pdf_data)return res.sendStatus(404);sendPdf(res,rows[0].pdf_data,`${rows[0].quote_number}.pdf`);}
  catch(error){next(error);}
});
app.post('/api/admin/salary-slips', ensureDb, requireAdmin, async(req,res,next)=>{
  try {
    const b=req.body||{};const {rows:workerRows}=await pool.query('SELECT * FROM workers WHERE id=$1',[b.worker_id]);if(!workerRows.length)return res.status(404).json({error:'Worker not found.'});
    const worker=workerRows[0],month=/^\d{4}-\d{2}$/.test(b.month||'')?b.month:new Date().toISOString().slice(0,7);
    const basic=number(b.basic_salary,number(worker.monthly_salary)),allowances=number(b.allowances),deductions=number(b.deductions),paidDays=number(b.paid_days,30),net=basic+allowances-deductions;
    if(net<0)return res.status(400).json({error:'Deductions cannot exceed gross salary.'});
    const pdf=makePdf('GALAXY PVC PANELS - SALARY SLIP',['Payroll statement',`Worker: ${worker.name}`,`Designation: ${worker.role||'Worker'}`,`Employee phone: ${worker.phone||'—'}`,`Salary month: ${month}`,`Paid days: ${paidDays}`,`Basic salary: Rs ${basic.toFixed(2)}`,`Allowances: Rs ${allowances.toFixed(2)}`,`Deductions: Rs ${deductions.toFixed(2)}`,`NET PAYABLE: Rs ${net.toFixed(2)}`,`Notes: ${safeText(b.notes,400)}`,'','This is a computer generated salary statement.']);
    const {rows}=await pool.query(`INSERT INTO salary_slips(worker_id,month,basic_salary,allowances,deductions,net_salary,paid_days,notes,pdf_data) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) ON CONFLICT(worker_id,month) DO UPDATE SET basic_salary=EXCLUDED.basic_salary,allowances=EXCLUDED.allowances,deductions=EXCLUDED.deductions,net_salary=EXCLUDED.net_salary,paid_days=EXCLUDED.paid_days,notes=EXCLUDED.notes,pdf_data=EXCLUDED.pdf_data,created_at=now() RETURNING id,worker_id,month,net_salary`,[worker.id,month,basic,allowances,deductions,net,paidDays,safeText(b.notes,1000)||null,pdf]);
    res.json({slip:rows[0],pdf:pdf.toString('base64'),filename:`salary-${worker.name.replace(/[^a-z0-9]/gi,'-')}-${month}.pdf`});
  }catch(error){next(error);}
});
app.get('/api/admin/salary-slips/:id/pdf', ensureDb, requireAdmin, async(req,res,next)=>{
  try {const {rows}=await pool.query('SELECT w.name,s.month,s.pdf_data FROM salary_slips s JOIN workers w ON w.id=s.worker_id WHERE s.id=$1',[req.params.id]);if(!rows.length||!rows[0].pdf_data)return res.sendStatus(404);sendPdf(res,rows[0].pdf_data,`salary-${rows[0].name}-${rows[0].month}.pdf`);}
  catch(error){next(error);}
});

app.use((error,_req,res,_next)=>{
  console.error(error);
  const status=error.code==='LIMIT_FILE_SIZE'?413:error.code==='23505'||error.code==='23503'?409:error.code==='23514'||error.code==='23502'?400:error.status||error.statusCode||500;
  res.status(status).json({error:error.message||'Unexpected server error.'});
});
if (fs.existsSync(publicDir)) {
  app.use(express.static(publicDir));
  app.use((req,res,next)=>{if(req.method!=='GET'||req.path.startsWith('/api/'))return next();res.sendFile(path.join(publicDir,'index.html'));});
}

async function start(){
  if(pool){try{await initializeDatabase();}catch(error){console.error('Database startup failed:',error.message);process.exitCode=1;return;}}
  app.listen(PORT,()=>console.log(`Galaxy PVC Panels API listening on http://localhost:${PORT}`));
}
start();
process.on('SIGTERM',async()=>{if(pool)await pool.end();process.exit(0);});
process.on('SIGINT',async()=>{if(pool)await pool.end();process.exit(0);});
