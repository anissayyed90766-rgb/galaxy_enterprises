# Galaxy PVC Panels - Website + Admin

Luxury black & gold storefront (matches the reference design) plus a password-only admin panel.
Backend: Node.js + Express. Database: Neon PostgreSQL.

## Quick start
1. Open `.env` and paste your Neon **pooled** connection string into `DATABASE_URL`.
2. Change `ADMIN_PASSWORD` (default `galaxy@123`).
3. `npm install`
4. Development: `npm run dev` -> website http://localhost:5173, admin http://localhost:5173/admin
5. Production: `npm run build && npm start` -> http://localhost:3001
6. Check `http://localhost:3001/api/health` shows `database: connected`.

Tables are created automatically on first start, and the 4 sample products from the design are added once.

## Admin: Website Editor (instant publishing)
Sign in at `/admin`, then press the gold **Website Editor** button (top of the sidebar).
Tabs: Logo & Menu, Home Banner, Feature Strip, Products Section, About Us, Services, Projects, Gallery, Contact & Social, Colours.
- Upload/replace images (logo, hero, about, projects, gallery). Large photos are resized automatically.
- Edit text, buttons, links, phone numbers, WhatsApp number, address, social links.
- **Save & Publish** makes changes live immediately. "Live preview" shows the site beside the editor.
- "Show prices on the public website" toggle: off = prices hidden, customers see "Price on request".

## Products (add / edit / delete)
Admin -> Products & Inventory: name, category (choose or type new), price, unit (e.g. sq.ft), description,
stock, image upload, "Show on home page", display order, visible on website. Changes appear on the site immediately.

## Other modules
Sales, purchases, expenses, stock + low-stock alerts, monthly P&L, analytics, quotation PDF,
workers, attendance, salary slips, projects, customer enquiries.

## Deploy
Use a Node host (Render, Railway, Fly.io). Set `DATABASE_URL`, `ADMIN_PASSWORD`, `JWT_SECRET`.
Build: `npm ci && npm run build` - Start: `npm start` - Health: `/api/health`. A `render.yaml` is included.

## Notes
- Never commit or share `.env`. Back up the Neon database regularly.
- Customer "Get a Quote" form saves the enquiry to the database and opens WhatsApp with details filled in.
- Social icons in the footer appear after you add links in the editor.
- Website images uploaded through the editor are stored in PostgreSQL (`site_images`).
