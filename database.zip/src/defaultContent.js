// Default website content. The admin "Website Editor" saves changes to PostgreSQL;
// anything the admin has not changed falls back to these values.
const uid = () => Math.random().toString(36).slice(2, 10);
export const newId = uid;

export const defaultContent = {
  theme: {gold: '#d8b05a'},
  brand: {logo: '/assets/galaxy-logo.png', name: 'Galaxy PVC Panels'},
  nav: [
    {id: 'n1', label: 'Home', href: '/', visible: true},
    {id: 'n2', label: 'About', href: '/#about', visible: true},
    {id: 'n3', label: 'Products', href: '/products', visible: true},
    {id: 'n4', label: 'Projects', href: '/#projects', visible: true},
    {id: 'n5', label: 'Gallery', href: '/#gallery', visible: true},
    {id: 'n6', label: 'Services', href: '/#services', visible: true},
    {id: 'n7', label: 'Contact', href: '/#contact', visible: true}
  ],
  header: {showAdminLogin: true, adminLoginLabel: 'Admin Login', quoteLabel: 'Get a Quote'},
  hero: {
    eyebrow: 'PREMIUM INTERIOR SOLUTIONS',
    title1: 'Galaxy', title2: 'PVC Panels',
    subtitle: 'Transform Your Space with Elegance',
    text: 'Modern. Durable. Stylish. Premium PVC panels for walls, ceilings, and more.',
    btn1Label: 'Explore Products', btn1Href: '/products',
    btn2Label: 'Contact Us', btn2Href: '/#contact',
    image: '/assets/seed/hero-interior.jpg'
  },
  features: [
    {id: 'f1', icon: 'droplet', label: 'Waterproof'},
    {id: 'f2', icon: 'shield', label: 'Termite & Pest Resistant'},
    {id: 'f3', icon: 'flame', label: 'Fire-Retardant Options'},
    {id: 'f4', icon: 'tools', label: 'Easy Installation'},
    {id: 'f5', icon: 'leaf', label: 'Low Maintenance'},
    {id: 'f6', icon: 'gem', label: 'Galaxy Silicone'},
    {id: 'f7', icon: 'clip', label: 'Metal Clips'}
  ],
  productsSection: {
    eyebrow: 'OUR PRODUCTS', heading: 'Premium PVC Designs for Modern Homes',
    buttonLabel: 'View All Products', showPrices: true, homeCount: 4,
    enquiryLabel: 'Enquire on WhatsApp', pageHeading: 'Our Products'
  },
  about: {
    eyebrow: 'ABOUT US', heading: 'Style That Stays, Quality That Lasts',
    paragraphs: [
      'Galaxy PVC Panels supplies premium PVC wall panels, ceiling panels and decorative interior panels from Kalewadi, Pimpri-Chinchwad.',
      'Our panels are built to be strong, waterproof and termite resistant, with a refined finish that is easy to install and simple to maintain.'
    ],
    points: ['Hard & strong construction', 'Waterproof & moisture-proof', 'Premium finish', 'Easy installation'],
    image: '/assets/galaxy-fluted-panel-poster.jpg'
  },
  services: {
    eyebrow: 'SERVICES', heading: 'Everything for a Flawless Finish',
    items: [
      {id: 's1', icon: 'layers', title: 'PVC Panel Supply', text: 'Wall panels, ceiling panels and charcoal panels in a range of designs.'},
      {id: 's2', icon: 'hammer', title: 'Professional Installation', text: 'Neat, precise installation for homes, offices and shops.'},
      {id: 's3', icon: 'light', title: 'Wall & Ceiling Paneling', text: 'Feature walls, TV units and ceilings that work with cove lighting.'},
      {id: 's4', icon: 'gem', title: 'Silicone & Metal Clips', text: 'Galaxy Silicone and metal clips for a secure, long-lasting fit.'}
    ]
  },
  projects: {eyebrow: 'PROJECTS', heading: 'Completed Installations', items: []},
  gallery: {
    eyebrow: 'GALLERY', heading: 'Interior Designs',
    images: [
      {id: 'g1', url: '/assets/seed/fluted-pvc-panels.jpg', caption: 'Fluted wall panel'},
      {id: 'g2', url: '/assets/seed/pvc-wall-panels.jpg', caption: 'Marble-look wall panel'},
      {id: 'g3', url: '/assets/seed/pvc-ceiling-panels.jpg', caption: 'Ceiling panel'},
      {id: 'g4', url: '/assets/seed/charcoal-panels.jpg', caption: 'Charcoal panel'}
    ]
  },
  contact: {
    eyebrow: 'CONTACT', heading: 'Visit Us or Message on WhatsApp',
    text: 'Tell us about your space and we will help you choose the right panels.',
    address: 'Kalewadi, Pimpri-Chinchwad, Maharashtra 411017',
    mapUrl: '',
    phones: ['9527929796', '8975101040'],
    whatsapp: '919527929796',
    email: ''
  },
  social: {instagram: '', facebook: '', youtube: ''},
  footer: {tagline: 'Upgrade Your Interiors with Galaxy'}
};

// Deep-merge saved content over defaults. Arrays from saved content replace default arrays.
export function mergeContent(base, saved) {
  if (Array.isArray(base)) return Array.isArray(saved) ? saved : base;
  if (base && typeof base === 'object') {
    const out = {...base};
    if (saved && typeof saved === 'object' && !Array.isArray(saved)) {
      for (const key of Object.keys(saved)) out[key] = key in base ? mergeContent(base[key], saved[key]) : saved[key];
    }
    return out;
  }
  return saved === undefined || saved === null ? base : saved;
}

export const fallbackProducts = [
  {id: 'd1', name: 'Fluted PVC Panels', category: 'PVC Wall Panels', price: 350, unit: 'sq.ft', image_url: '/assets/seed/fluted-pvc-panels.jpg', description: 'Premium fluted PVC wall panels with a warm wood-look finish.', featured: true},
  {id: 'd2', name: 'PVC Wall Panels', category: 'PVC Wall Panels', price: 320, unit: 'sq.ft', image_url: '/assets/seed/pvc-wall-panels.jpg', description: 'Marble-look PVC wall panels for a clean, luxurious interior.', featured: true},
  {id: 'd3', name: 'PVC Ceiling Panels', category: 'PVC Ceiling Panels', price: 300, unit: 'sq.ft', image_url: '/assets/seed/pvc-ceiling-panels.jpg', description: 'Elegant PVC ceiling panels that work with cove lighting.', featured: true},
  {id: 'd4', name: 'Charcoal Panels', category: 'Charcoal Panels', price: 370, unit: 'sq.ft', image_url: '/assets/seed/charcoal-panels.jpg', description: 'Deep charcoal fluted panels for a bold statement wall.', featured: true}
];
