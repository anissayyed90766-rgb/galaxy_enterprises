import React, {useEffect, useMemo, useState} from 'react';
import {ArrowRight, ArrowUpRight, ChevronDown, Facebook, Instagram, Layers3, MapPin, Menu, MessageCircle, Phone, ShieldCheck, X, Youtube, Check, Mail} from 'lucide-react';
import {api} from '../common';
import {ICONS} from '../icons';
import {defaultContent, mergeContent, fallbackProducts} from '../defaultContent';
import './site.css';

/* ---------- helpers ---------- */
const digits = v => String(v || '').replace(/\D/g, '');
const telHref = v => { const d = digits(v); return `tel:${d.length === 10 ? '+91' + d : '+' + d}`; };
const waLink = (c, message) => `https://wa.me/${digits(c.contact.whatsapp)}?text=${encodeURIComponent(message)}`;
const priceText = p => (p.price === null || p.price === undefined || p.price === '') ? null : `₹ ${Number(p.price).toLocaleString('en-IN', {maximumFractionDigits: 2})} / ${p.unit || 'piece'}`;
const fixHref = href => href || '#';

function useSite() {
  const [state, setState] = useState({loaded: false, content: defaultContent, products: []});
  useEffect(() => {
    let alive = true;
    Promise.allSettled([api('/public/site'), api('/public/products')]).then(([siteRes, prodRes]) => {
      if (!alive) return;
      const saved = siteRes.status === 'fulfilled' ? siteRes.value : {};
      // If the API/database is unreachable, still show a presentable site using the default products.
      const products = prodRes.status === 'fulfilled' && Array.isArray(prodRes.value) ? prodRes.value : fallbackProducts;
      setState({loaded: true, content: mergeContent(defaultContent, saved), products});
    });
    return () => { alive = false; };
  }, []);
  return state;
}

/* ---------- small pieces ---------- */
function Eyebrow({children}) { return <div className="gx-eyebrow"><i />{children}</div>; }

function Header({c, categories, onQuote}) {
  const [open, setOpen] = useState(false);
  const path = window.location.pathname;
  const items = c.nav.filter(n => n.visible !== false);
  const isActive = href => href === '/' ? (path === '/' && !window.location.hash) : (!href.includes('#') && href !== '#' && path.startsWith(href));
  return (
    <header className="gx-header">
      <div className="gx-header-inner">
        <a href="/" className="gx-logo" aria-label={c.brand.name}><img src={c.brand.logo} alt={c.brand.name} /></a>
        <nav className={`gx-nav ${open ? 'open' : ''}`} aria-label="Main">
          {items.map(n => {
            const isProducts = n.href === '/products';
            return (
              <div className={`gx-nav-item ${isProducts && categories.length ? 'has-menu' : ''}`} key={n.id}>
                <a href={fixHref(n.href)} className={isActive(n.href) ? 'active' : ''} onClick={() => setOpen(false)}>
                  {n.label}{isProducts && categories.length > 0 && <ChevronDown size={13} />}
                </a>
                {isProducts && categories.length > 0 && (
                  <div className="gx-dropdown">
                    {categories.map(cat => <a key={cat} href={`/products?category=${encodeURIComponent(cat)}`} onClick={() => setOpen(false)}>{cat}</a>)}
                  </div>
                )}
              </div>
            );
          })}
          <div className="gx-nav-mobile-actions">
            {c.header.showAdminLogin && <a className="gx-btn gx-btn-outline" href="/admin"><ShieldCheck size={16} />{c.header.adminLoginLabel}</a>}
            <button className="gx-btn gx-btn-gold" onClick={() => { setOpen(false); onQuote(); }}>{c.header.quoteLabel}<ArrowRight size={16} /></button>
          </div>
        </nav>
        <div className="gx-header-actions">
          {c.header.showAdminLogin && <a className="gx-btn gx-btn-outline gx-pill" href="/admin"><ShieldCheck size={17} />{c.header.adminLoginLabel}</a>}
          <button className="gx-btn gx-btn-gold gx-pill" onClick={() => onQuote()}>{c.header.quoteLabel}<ArrowRight size={16} /></button>
        </div>
        <button className="gx-burger" onClick={() => setOpen(!open)} aria-label="Toggle menu">{open ? <X size={24} /> : <Menu size={24} />}</button>
      </div>
    </header>
  );
}

function Hero({c}) {
  const h = c.hero;
  return (
    <section className="gx-hero" id="home">
      <div className="gx-hero-copy">
        <div className="gx-hero-eyebrow">{h.eyebrow}</div>
        <h1><span className="w">{h.title1}</span> <span className="g">{h.title2}</span></h1>
        <h2>{h.subtitle}</h2>
        <p>{h.text}</p>
        <div className="gx-hero-buttons">
          {h.btn1Label && <a className="gx-btn gx-btn-gold" href={fixHref(h.btn1Href)}>{h.btn1Label}<ArrowRight size={17} /></a>}
          {h.btn2Label && <a className="gx-btn gx-btn-outline" href={fixHref(h.btn2Href)}>{h.btn2Label}</a>}
        </div>
      </div>
      <div className="gx-hero-art">
        {h.image && <img src={h.image} alt="Premium PVC panel interior" />}
        <span className="gx-hero-line" />
      </div>
    </section>
  );
}

function FeatureStrip({c}) {
  if (!c.features.length) return null;
  return (
    <section className="gx-features" aria-label="Key features">
      {c.features.map(f => {
        const Icon = ICONS[f.icon] || ICONS.star;
        return <div className="gx-feature" key={f.id}><Icon size={30} strokeWidth={1.4} /><span>{f.label}</span></div>;
      })}
    </section>
  );
}

function ProductCard({p, showPrices, onOpen}) {
  const price = showPrices ? priceText(p) : null;
  return (
    <article className="gx-card" onClick={() => onOpen(p)} tabIndex={0} role="button" aria-label={`View ${p.name}`}
      onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onOpen(p); } }}>
      <div className="gx-card-img">
        {p.image_url ? <img src={p.image_url} alt={p.name} loading="lazy" /> : <div className="gx-card-ph"><Layers3 size={38} /><span>{p.category}</span></div>}
      </div>
      <div className="gx-card-info">
        <div><b>{p.name}</b><small>{price || 'Price on request'}</small></div>
        <span className="gx-card-go"><ArrowRight size={17} /></span>
      </div>
    </article>
  );
}

function ProductsSection({c, products, onOpen}) {
  const s = c.productsSection;
  const featured = products.filter(p => p.featured);
  const list = (featured.length ? featured : products).slice(0, Math.max(1, Number(s.homeCount) || 4));
  return (
    <section className="gx-products" id="products">
      <div className="gx-section-head">
        <div><Eyebrow>{s.eyebrow}</Eyebrow><h2>{s.heading}</h2></div>
        <a className="gx-btn gx-btn-outline gx-small" href="/products">{s.buttonLabel}<ArrowRight size={15} /></a>
      </div>
      {list.length ? <div className="gx-grid gx-grid-home">{list.map(p => <ProductCard key={p.id} p={p} showPrices={s.showPrices} onOpen={onOpen} />)}</div>
        : <p className="gx-empty">Products will appear here soon.</p>}
    </section>
  );
}

function About({c}) {
  const a = c.about;
  return (
    <section className="gx-section gx-about" id="about">
      <div className="gx-about-grid">
        <div className="gx-about-img">{a.image && <img src={a.image} alt="About Galaxy PVC Panels" loading="lazy" />}</div>
        <div>
          <Eyebrow>{a.eyebrow}</Eyebrow>
          <h2>{a.heading}</h2>
          {a.paragraphs.map((t, i) => <p key={i}>{t}</p>)}
          {a.points.length > 0 && <ul className="gx-points">{a.points.map((t, i) => <li key={i}><Check size={16} />{t}</li>)}</ul>}
        </div>
      </div>
    </section>
  );
}

function Services({c}) {
  const s = c.services;
  if (!s.items.length) return null;
  return (
    <section className="gx-section" id="services">
      <div className="gx-section-head"><div><Eyebrow>{s.eyebrow}</Eyebrow><h2>{s.heading}</h2></div></div>
      <div className="gx-services">
        {s.items.map(i => { const Icon = ICONS[i.icon] || ICONS.star; return (
          <div className="gx-service" key={i.id}><span><Icon size={24} strokeWidth={1.5} /></span><h3>{i.title}</h3><p>{i.text}</p></div>
        ); })}
      </div>
    </section>
  );
}

function Projects({c}) {
  const p = c.projects;
  return (
    <section className="gx-section" id="projects">
      <div className="gx-section-head"><div><Eyebrow>{p.eyebrow}</Eyebrow><h2>{p.heading}</h2></div></div>
      {p.items.length ? (
        <div className="gx-projects">
          {p.items.map(i => (
            <article className="gx-project" key={i.id}>
              <div className="gx-project-img">{i.image ? <img src={i.image} alt={i.title} loading="lazy" /> : <Layers3 size={36} />}</div>
              <div className="gx-project-body"><h3>{i.title}</h3>{i.location && <small><MapPin size={13} />{i.location}</small>}{i.text && <p>{i.text}</p>}</div>
            </article>
          ))}
        </div>
      ) : <p className="gx-empty">Our completed installations will be showcased here soon.</p>}
    </section>
  );
}

function Gallery({c}) {
  const g = c.gallery;
  const [light, setLight] = useState(null);
  useEffect(() => { const k = e => e.key === 'Escape' && setLight(null); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, []);
  if (!g.images.length) return null;
  return (
    <section className="gx-section" id="gallery">
      <div className="gx-section-head"><div><Eyebrow>{g.eyebrow}</Eyebrow><h2>{g.heading}</h2></div></div>
      <div className="gx-gallery">
        {g.images.map(i => (
          <button className="gx-gal-item" key={i.id} onClick={() => setLight(i)} aria-label={`Open ${i.caption || 'image'}`}>
            <img src={i.url} alt={i.caption || 'Gallery image'} loading="lazy" />{i.caption && <span>{i.caption}</span>}
          </button>
        ))}
      </div>
      {light && <div className="gx-lightbox" onClick={() => setLight(null)}><button aria-label="Close"><X size={26} /></button><img src={light.url} alt={light.caption || ''} /></div>}
    </section>
  );
}

function Contact({c}) {
  const k = c.contact;
  return (
    <section className="gx-section" id="contact">
      <div className="gx-contact">
        <div>
          <Eyebrow>{k.eyebrow}</Eyebrow>
          <h2>{k.heading}</h2>
          <p>{k.text}</p>
          <a className="gx-btn gx-btn-gold" href={waLink(c, 'Hello Galaxy PVC Panels! I would like some information.')} target="_blank" rel="noopener noreferrer"><MessageCircle size={18} />Chat on WhatsApp</a>
        </div>
        <div className="gx-contact-cards">
          <a className="gx-contact-card" href={k.mapUrl || `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(k.address)}`} target="_blank" rel="noopener noreferrer"><MapPin size={22} /><span><small>ADDRESS</small>{k.address}</span></a>
          <div className="gx-contact-card"><Phone size={22} /><span><small>PHONE</small>{k.phones.filter(Boolean).map((ph, i) => <React.Fragment key={i}>{i > 0 && ' | '}<a href={telHref(ph)}>{ph}</a></React.Fragment>)}</span></div>
          {k.email && <a className="gx-contact-card" href={`mailto:${k.email}`}><Mail size={22} /><span><small>EMAIL</small>{k.email}</span></a>}
        </div>
      </div>
    </section>
  );
}

function InfoBar({c}) {
  const k = c.contact, s = c.social;
  const socials = [[Instagram, s.instagram, 'Instagram'], [Facebook, s.facebook, 'Facebook'], [Youtube, s.youtube, 'YouTube']].filter(x => x[1]);
  return (
    <footer className="gx-infobar">
      <div className="gx-info-cell"><MapPin size={30} strokeWidth={1.6} /><span>{k.address}</span></div>
      <div className="gx-info-cell"><Phone size={28} strokeWidth={1.6} /><span className="gx-phones">{k.phones.filter(Boolean).map((ph, i) => <React.Fragment key={i}>{i > 0 && <em>|</em>}<a href={telHref(ph)}>{ph}</a></React.Fragment>)}</span></div>
      {socials.length > 0 && <div className="gx-info-cell gx-socials">{socials.map(([Icon, url, label]) => <a key={label} href={url} target="_blank" rel="noopener noreferrer" aria-label={label}><Icon size={26} /></a>)}</div>}
      <div className="gx-info-cell gx-tagline">{c.footer.tagline}</div>
    </footer>
  );
}

/* ---------- modals ---------- */
function Modal({onClose, children, wide}) {
  useEffect(() => {
    const k = e => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', k);
    document.body.style.overflow = 'hidden';
    return () => { window.removeEventListener('keydown', k); document.body.style.overflow = ''; };
  }, [onClose]);
  return <div className="gx-modal-bg" onMouseDown={e => e.target === e.currentTarget && onClose()}><div className={`gx-modal ${wide ? 'wide' : ''}`} role="dialog" aria-modal="true"><button className="gx-modal-x" onClick={onClose} aria-label="Close"><X size={20} /></button>{children}</div></div>;
}

function ProductModal({c, p, onClose, onQuote}) {
  const price = c.productsSection.showPrices ? priceText(p) : null;
  const msg = `Hello Galaxy PVC Panels! I am interested in ${p.name}${p.category ? ` (${p.category})` : ''}. Please share ${price ? 'availability and' : 'the price,'} details and a quotation.`;
  return (
    <Modal onClose={onClose} wide>
      <div className="gx-pm">
        <div className="gx-pm-img">{p.image_url ? <img src={p.image_url} alt={p.name} /> : <Layers3 size={56} />}</div>
        <div className="gx-pm-body">
          <small>{p.category}</small>
          <h3>{p.name}</h3>
          {price && <div className="gx-pm-price">{price}</div>}
          {p.description && <p>{p.description}</p>}
          <dl>{p.quality && <><dt>Quality</dt><dd>{p.quality}</dd></>}{p.dimensions && <><dt>Dimensions</dt><dd>{p.dimensions}</dd></>}</dl>
          <div className="gx-pm-actions">
            <a className="gx-btn gx-btn-gold" href={waLink(c, msg)} target="_blank" rel="noopener noreferrer"><MessageCircle size={18} />{c.productsSection.enquiryLabel}</a>
            <button className="gx-btn gx-btn-outline" onClick={() => onQuote(p.name)}>Request a Quote</button>
          </div>
        </div>
      </div>
    </Modal>
  );
}

function QuoteModal({c, products, initialProduct, onClose}) {
  const [f, setF] = useState({name: '', phone: '', product: initialProduct || '', message: ''});
  const [sent, setSent] = useState(false);
  const set = k => e => setF({...f, [k]: e.target.value});
  function submit(e) {
    e.preventDefault();
    const text = `Hello Galaxy PVC Panels! I would like a quotation.\nName: ${f.name}\nPhone: ${f.phone}\nProduct: ${f.product || 'General enquiry'}${f.message ? `\nDetails: ${f.message}` : ''}`;
    window.open(waLink(c, text), '_blank', 'noopener,noreferrer');
    api('/public/enquiries', {method: 'POST', body: JSON.stringify({customer_name: f.name, phone: f.phone, category: f.product || null, message: f.message || null})}).catch(() => {});
    setSent(true);
  }
  return (
    <Modal onClose={onClose}>
      {sent ? (
        <div className="gx-thanks"><span><Check size={28} /></span><h3>Thank you!</h3><p>Your enquiry has been opened in WhatsApp. We will get back to you shortly.</p><button className="gx-btn gx-btn-gold" onClick={onClose}>Close</button></div>
      ) : (
        <form className="gx-form" onSubmit={submit}>
          <h3>Get a Quote</h3><p>Tell us what you need. Your enquiry opens in WhatsApp with these details filled in.</p>
          <label>Your name<input required value={f.name} onChange={set('name')} autoComplete="name" /></label>
          <label>Phone number<input required inputMode="tel" value={f.phone} onChange={set('phone')} autoComplete="tel" /></label>
          <label>Product<input list="gx-products" value={f.product} onChange={set('product')} placeholder="Choose or type a product" /><datalist id="gx-products">{products.map(p => <option key={p.id} value={p.name} />)}</datalist></label>
          <label>Message (area, room, requirements)<textarea rows="3" value={f.message} onChange={set('message')} /></label>
          <button className="gx-btn gx-btn-gold gx-full" type="submit"><MessageCircle size={18} />Send on WhatsApp</button>
        </form>
      )}
    </Modal>
  );
}

/* ---------- pages ---------- */
function Shell({c, products, children}) {
  const [product, setProduct] = useState(null);
  const [quote, setQuote] = useState(null);   // null = closed, string = initial product
  const categories = useMemo(() => [...new Set(products.map(p => p.category).filter(Boolean))], [products]);
  const openQuote = (name = '') => { setProduct(null); setQuote(name); };
  return (
    <div className="gx" style={{'--gx-gold': c.theme.gold}}>
      <Header c={c} categories={categories} onQuote={() => openQuote('')} />
      {children({openProduct: setProduct})}
      <InfoBar c={c} />
      <a className="gx-wa-float" href={waLink(c, 'Hello Galaxy PVC Panels!')} target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp"><MessageCircle size={26} /></a>
      {product && <ProductModal c={c} p={product} onClose={() => setProduct(null)} onQuote={openQuote} />}
      {quote !== null && <QuoteModal c={c} products={products} initialProduct={quote} onClose={() => setQuote(null)} />}
    </div>
  );
}

function HomePage({c, products}) {
  return (
    <Shell c={c} products={products}>
      {({openProduct}) => (
        <main>
          <Hero c={c} />
          <FeatureStrip c={c} />
          <ProductsSection c={c} products={products} onOpen={openProduct} />
          <About c={c} />
          <Services c={c} />
          <Projects c={c} />
          <Gallery c={c} />
          <Contact c={c} />
        </main>
      )}
    </Shell>
  );
}

function ProductsPage({c, products}) {
  const initial = new URLSearchParams(window.location.search).get('category') || 'All';
  const [cat, setCat] = useState(initial);
  const [q, setQ] = useState('');
  const cats = ['All', ...new Set(products.map(p => p.category).filter(Boolean))];
  const shown = products.filter(p => (cat === 'All' || p.category === cat) && `${p.name} ${p.category} ${p.description || ''}`.toLowerCase().includes(q.toLowerCase()));
  return (
    <Shell c={c} products={products}>
      {({openProduct}) => (
        <main className="gx-page">
          <section className="gx-products gx-products-page">
            <div className="gx-section-head"><div><Eyebrow>{c.productsSection.eyebrow}</Eyebrow><h2>{c.productsSection.pageHeading}</h2></div>
              <input className="gx-search" placeholder="Search products..." value={q} onChange={e => setQ(e.target.value)} aria-label="Search products" /></div>
            <div className="gx-chips">{cats.map(x => <button key={x} className={x === cat ? 'on' : ''} onClick={() => setCat(x)}>{x}</button>)}</div>
            {shown.length ? <div className="gx-grid">{shown.map(p => <ProductCard key={p.id} p={p} showPrices={c.productsSection.showPrices} onOpen={openProduct} />)}</div>
              : <p className="gx-empty">No products found.</p>}
          </section>
        </main>
      )}
    </Shell>
  );
}


function DeveloperCredit(){
  const [visible,setVisible]=useState(()=>sessionStorage.getItem('gx-dev-credit-dismissed')!=='1');
  if(!visible)return null;
  return <div className="gx-dev-credit" role="complementary" aria-label="Developer credit">
    <a href="https://animated-portfolio-six-mauve.vercel.app/" target="_blank" rel="noopener noreferrer" aria-label="Design and developed by anis_sayyad01">
      <span className="gx-dev-credit-icon">&lt;/&gt;</span><span>Design &amp; Developed by <b>anis_sayyad01</b></span>
    </a>
    <button type="button" aria-label="Dismiss developer credit" onClick={()=>{sessionStorage.setItem('gx-dev-credit-dismissed','1');setVisible(false);}}>×</button>
  </div>;
}

export default function PublicSite() {
  const {loaded, content, products} = useSite();
  useEffect(() => {
    if (!loaded) return;
    document.title = `${content.brand.name} | Premium PVC Wall & Ceiling Panels`;
    if (window.location.hash) setTimeout(() => document.getElementById(window.location.hash.slice(1))?.scrollIntoView(), 60);
  }, [loaded]);
  if (!loaded) return <div className="gx gx-loading"><img src="/assets/galaxy-logo.png" alt="Galaxy PVC Panels" /></div>;
  return <><DeveloperCredit />{window.location.pathname.startsWith('/products') ? <ProductsPage c={content} products={products} /> : <HomePage c={content} products={products} />}</>;
}
