export const categories = ['PVC Wall Panels','PVC Ceiling Panels','Charcoal Panels','Louvers','UV Marble Sheets','WPC Panels'];
export const starterProducts = [
 {id:'sample-1',name:'Premium PVC Wall Panel',category:'PVC Wall Panels',description:'Modern decorative wall finish for living rooms, bedrooms and commercial spaces.',price:null,quality:'Premium',stock:0,image_url:'',active:true},
 {id:'sample-2',name:'Designer PVC Ceiling Panel',category:'PVC Ceiling Panels',description:'Elegant ceiling finish with a clean, contemporary look.',price:null,quality:'Premium',stock:0,image_url:'',active:true},
 {id:'sample-3',name:'Charcoal Fluted Panel',category:'Charcoal Panels',description:'Statement-making fluted texture for feature walls and interiors.',price:null,quality:'Premium',stock:0,image_url:'',active:true},
 {id:'sample-4',name:'Decorative Louvers',category:'Louvers',description:'Linear architectural detail for modern residential and retail spaces.',price:null,quality:'Premium',stock:0,image_url:'',active:true},
 {id:'sample-5',name:'UV Marble Sheet',category:'UV Marble Sheets',description:'Marble-inspired decorative surface for a refined interior finish.',price:null,quality:'Premium',stock:0,image_url:'',active:true},
 {id:'sample-6',name:'WPC Panel',category:'WPC Panels',description:'Versatile wood-plastic composite panel for interior applications.',price:null,quality:'Premium',stock:0,image_url:'',active:true}
];