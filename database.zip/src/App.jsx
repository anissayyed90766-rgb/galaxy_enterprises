import React from 'react';
import PublicSite from './site/PublicSite';
import AdminLogin from './admin/AdminLogin';
import Dashboard from './admin/Dashboard';

export default function App() {
  const path = window.location.pathname;
  if (path.startsWith('/admin/dashboard')) return <Dashboard />;
  if (path.startsWith('/admin')) return <AdminLogin />;
  return <PublicSite />;
}
