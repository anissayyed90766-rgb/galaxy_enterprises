import {Droplet, ShieldCheck, Flame, Wrench, Leaf, Gem, Paperclip, Star, Truck, CheckCircle2, Sparkles, Home, Hammer, Ruler, Layers3, PaintBucket, Lightbulb, Award, Clock, ThumbsUp} from 'lucide-react';

// Icons the admin can choose for feature-strip items and services.
export const ICONS = {
  droplet: Droplet, shield: ShieldCheck, flame: Flame, tools: Wrench, leaf: Leaf, gem: Gem, clip: Paperclip,
  star: Star, truck: Truck, check: CheckCircle2, sparkles: Sparkles, home: Home, hammer: Hammer, ruler: Ruler,
  layers: Layers3, paint: PaintBucket, light: Lightbulb, award: Award, clock: Clock, thumbs: ThumbsUp
};
export const ICON_KEYS = Object.keys(ICONS);
