import React, {useEffect, useRef, useState} from 'react';
import {ArrowDown, ArrowUp, Eye, EyeOff, ExternalLink, ImagePlus, Loader2, Plus, Save, Trash2, Boxes, UploadCloud} from 'lucide-react';
import {api} from '../common';
import {ICON_KEYS} from '../icons';
import {defaultContent, mergeContent, newId} from '../defaultContent';

/* Shrinks big photos before upload so pages load fast and the database stays small. */
async function prepareImage(file, maxDim = 2000) {
  if (file.type === 'image/svg+xml' || file.size < 350 * 1024) return file;
  try {
    const bmp = await createImageBitmap(file);
    const scale = Math.min(1, maxDim / Math.max(bmp.width, bmp.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(bmp.width * scale); canvas.height = Math.round(bmp.height * scale);
    canvas.getContext('2d').drawImage(bmp, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise(res => canvas.toBlob(res, 'image/webp', 0.9));
    return blob && blob.size < file.size ? new File([blob], file.name.replace(/\.\w+$/, '') + '.webp', {type: 'image/webp'}) : file;
  } catch { return file; }
}
async function uploadImage(file) {
  const fd = new FormData();
  fd.append('image', await prepareImage(file));
  return (await api('/admin/site/image', {method: 'POST', body: fd})).url;
}
const move = (arr, i, dir) => { const j = i + dir; if (j < 0 || j >= arr.length) return arr; const a = [...arr]; [a[i], a[j]] = [a[j], a[i]]; return a; };

/* ---------- small form pieces ---------- */
function Text({label, value, onChange, rows, hint, placeholder}) {
  return <label className="se-field">{label}{rows ? <textarea rows={rows} value={value ?? ''} onChange={e => onChange(e.target.value)} placeholder={placeholder} /> : <input value={value ?? ''} onChange={e => onChange(e.target.value)} placeholder={placeholder} />}{hint && <small>{hint}</small>}</label>;
}
function Toggle({label, checked, onChange, hint}) {
  return <label className="se-toggle"><input type="checkbox" checked={!!checked} onChange={e => onChange(e.target.checked)} /><span><b>{label}</b>{hint && <small>{hint}</small>}</span></label>;
}
function ImageField({label, value, onChange, setError, hint}) {
  const ref = useRef(null);
  const [busy, setBusy] = useState(false);
  async function pick(e) {
    const file = e.target.files?.[0]; e.target.value = '';
    if (!file) return;
    setBusy(true); setError('');
    try { onChange(await uploadImage(file)); } catch (err) { setError(err.message); } finally { setBusy(false); }
  }
  return (
    <div className="se-field">
      {label}
      <div className="se-image">
        <div className="se-thumb">{value ? <img src={value} alt="" /> : <ImagePlus size={26} />}</div>
        <div className="se-image-actions">
          <input ref={ref} type="file" accept="image/jpeg,image/png,image/webp,image/avif,image/svg+xml" hidden onChange={pick} />
          <button type="button" className="btn btn-primary" disabled={busy} onClick={() => ref.current.click()}>{busy ? <Loader2 size={15} className="spin" /> : <UploadCloud size={15} />}{value ? 'Replace image' : 'Upload image'}</button>
          {value && <button type="button" className="btn btn-soft" onClick={() => onChange('')}><Trash2 size={14} />Remove</button>}
          {hint && <small>{hint}</small>}
        </div>
      </div>
    </div>
  );
}
function Row({children, onUp, onDown, onDelete, extra}) {
  return (
    <div className="se-row">
      <div className="se-row-body">{children}</div>
      <div className="se-row-tools">
        {extra}
        <button type="button" onClick={onUp} title="Move up"><ArrowUp size={15} /></button>
        <button type="button" onClick={onDown} title="Move down"><ArrowDown size={15} /></button>
        <button type="button" onClick={onDelete} title="Delete" className="danger"><Trash2 size={15} /></button>
      </div>
    </div>
  );
}
function IconSelect({value, onChange}) {
  return <label className="se-field">Icon<select value={value} onChange={e => onChange(e.target.value)}>{ICON_KEYS.map(k => <option key={k} value={k}>{k}</option>)}</select></label>;
}
const Grid = ({children}) => <div className="se-grid">{children}</div>;
const AddButton = ({onClick, children}) => <button type="button" className="btn btn-soft se-add" onClick={onClick}><Plus size={15} />{children}</button>;

const TABS = [
  ['brand', 'Logo & Menu'], ['hero', 'Home Banner'], ['features', 'Feature Strip'], ['products', 'Products Section'],
  ['about', 'About Us'], ['services', 'Services'], ['projects', 'Projects'], ['gallery', 'Gallery'], ['contact', 'Contact & Social'], ['theme', 'Colours']
];

export default function SiteEditor({showNotice, setError, goProducts}) {
  const [content, setContent] = useState(null);
  const [tab, setTab] = useState('hero');
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [preview, setPreview] = useState(false);
  const [previewKey, setPreviewKey] = useState(0);
  const [uploading, setUploading] = useState(false);
  const galleryRef = useRef(null);

  useEffect(() => {
    api('/admin/site').then(r => setContent(mergeContent(defaultContent, r.content))).catch(e => { setError(e.message); setContent(structuredClone(defaultContent)); });
  }, []);
  useEffect(() => {
    const warn = e => { if (dirty) { e.preventDefault(); e.returnValue = ''; } };
    window.addEventListener('beforeunload', warn); return () => window.removeEventListener('beforeunload', warn);
  }, [dirty]);

  if (!content) return <div className="loading">Loading website content…</div>;
  const upd = fn => { setContent(c => { const d = structuredClone(c); fn(d); return d; }); setDirty(true); };

  async function save() {
    setSaving(true); setError('');
    try { await api('/admin/site', {method: 'PUT', body: JSON.stringify({content})}); setDirty(false); setPreviewKey(k => k + 1); showNotice('Website updated. Changes are live now.'); }
    catch (e) { setError(e.message); } finally { setSaving(false); }
  }
  async function addGalleryImages(e) {
    const files = [...(e.target.files || [])]; e.target.value = '';
    if (!files.length) return;
    setUploading(true); setError('');
    try {
      const added = [];
      for (const f of files) added.push({id: newId(), url: await uploadImage(f), caption: ''});
      upd(d => { d.gallery.images.push(...added); });
    } catch (err) { setError(err.message); } finally { setUploading(false); }
  }

  const c = content;
  return (
    <div className="se">
      <section className="new-panel se-top">
        <div>
          <h2>Website Editor</h2>
          <p>Edit everything customers see on the website: images, text, prices display, contact details and more. Press <b>Save &amp; Publish</b> and the changes go live instantly.</p>
        </div>
        <div className="se-top-actions">
          <button type="button" className="btn btn-soft" onClick={goProducts}><Boxes size={15} />Add / edit / delete products</button>
          <button type="button" className="btn btn-soft" onClick={() => setPreview(!preview)}>{preview ? <EyeOff size={15} /> : <Eye size={15} />}{preview ? 'Hide preview' : 'Live preview'}</button>
          <a className="btn btn-soft" href="/" target="_blank" rel="noreferrer"><ExternalLink size={15} />Open website</a>
          <button type="button" className="btn btn-primary" onClick={save} disabled={saving || !dirty}>{saving ? <Loader2 size={15} className="spin" /> : <Save size={15} />}Save &amp; Publish</button>
        </div>
      </section>
      {dirty && <div className="se-dirty">You have unsaved changes. Press “Save &amp; Publish” to make them live.</div>}

      <div className={`se-layout ${preview ? 'with-preview' : ''}`}>
        <div>
          <div className="se-tabs" role="tablist">{TABS.map(([id, label]) => <button key={id} role="tab" aria-selected={tab === id} className={tab === id ? 'on' : ''} onClick={() => setTab(id)}>{label}</button>)}</div>
          <section className="new-panel se-panel">

            {tab === 'brand' && <>
              <h3>Logo</h3>
              <ImageField label="Website logo" value={c.brand.logo} setError={setError} onChange={v => upd(d => { d.brand.logo = v || defaultContent.brand.logo; })} hint="Use a PNG with a transparent or black background for the dark header." />
              <Text label="Business name" value={c.brand.name} onChange={v => upd(d => { d.brand.name = v; })} />
              <h3>Menu</h3>
              {c.nav.map((n, i) => (
                <Row key={n.id} onUp={() => upd(d => { d.nav = move(d.nav, i, -1); })} onDown={() => upd(d => { d.nav = move(d.nav, i, 1); })} onDelete={() => upd(d => { d.nav.splice(i, 1); })}
                  extra={<button type="button" title={n.visible === false ? 'Hidden - click to show' : 'Visible - click to hide'} onClick={() => upd(d => { d.nav[i].visible = d.nav[i].visible === false; })}>{n.visible === false ? <EyeOff size={15} /> : <Eye size={15} />}</button>}>
                  <Grid><Text label="Menu text" value={n.label} onChange={v => upd(d => { d.nav[i].label = v; })} /><Text label="Link" value={n.href} onChange={v => upd(d => { d.nav[i].href = v; })} hint="Examples: /products, /#about, /#contact" /></Grid>
                </Row>
              ))}
              <AddButton onClick={() => upd(d => { d.nav.push({id: newId(), label: 'New link', href: '/#contact', visible: true}); })}>Add menu item</AddButton>
              <h3>Header buttons</h3>
              <Grid>
                <Text label="Quote button text" value={c.header.quoteLabel} onChange={v => upd(d => { d.header.quoteLabel = v; })} />
                <Text label="Admin login button text" value={c.header.adminLoginLabel} onChange={v => upd(d => { d.header.adminLoginLabel = v; })} />
              </Grid>
              <Toggle label="Show “Admin Login” button on the public website" checked={c.header.showAdminLogin} onChange={v => upd(d => { d.header.showAdminLogin = v; })} hint="If hidden, you can still sign in at /admin." />
            </>}

            {tab === 'hero' && <>
              <ImageField label="Hero banner image" value={c.hero.image} setError={setError} onChange={v => upd(d => { d.hero.image = v; })} hint="Wide interior photo works best (landscape)." />
              <Text label="Small heading" value={c.hero.eyebrow} onChange={v => upd(d => { d.hero.eyebrow = v; })} />
              <Grid><Text label="Title - white part" value={c.hero.title1} onChange={v => upd(d => { d.hero.title1 = v; })} /><Text label="Title - gold part" value={c.hero.title2} onChange={v => upd(d => { d.hero.title2 = v; })} /></Grid>
              <Text label="Sub-heading" value={c.hero.subtitle} onChange={v => upd(d => { d.hero.subtitle = v; })} />
              <Text label="Description" rows={3} value={c.hero.text} onChange={v => upd(d => { d.hero.text = v; })} />
              <Grid>
                <Text label="Button 1 text" value={c.hero.btn1Label} onChange={v => upd(d => { d.hero.btn1Label = v; })} />
                <Text label="Button 1 link" value={c.hero.btn1Href} onChange={v => upd(d => { d.hero.btn1Href = v; })} />
                <Text label="Button 2 text" value={c.hero.btn2Label} onChange={v => upd(d => { d.hero.btn2Label = v; })} />
                <Text label="Button 2 link" value={c.hero.btn2Href} onChange={v => upd(d => { d.hero.btn2Href = v; })} />
              </Grid>
            </>}

            {tab === 'features' && <>
              <p className="se-help">The icon strip under the banner (Waterproof, Easy Installation, etc.).</p>
              {c.features.map((f, i) => (
                <Row key={f.id} onUp={() => upd(d => { d.features = move(d.features, i, -1); })} onDown={() => upd(d => { d.features = move(d.features, i, 1); })} onDelete={() => upd(d => { d.features.splice(i, 1); })}>
                  <Grid><IconSelect value={f.icon} onChange={v => upd(d => { d.features[i].icon = v; })} /><Text label="Text" value={f.label} onChange={v => upd(d => { d.features[i].label = v; })} /></Grid>
                </Row>
              ))}
              <AddButton onClick={() => upd(d => { d.features.push({id: newId(), icon: 'star', label: 'New feature'}); })}>Add feature</AddButton>
            </>}

            {tab === 'products' && <>
              <p className="se-help">Product photos, names, prices and descriptions are managed in <b>Products</b>. Here you control how the product section looks.</p>
              <button type="button" className="btn btn-primary" onClick={goProducts}><Boxes size={15} />Open product manager</button>
              <Toggle label="Show prices on the public website" checked={c.productsSection.showPrices} onChange={v => upd(d => { d.productsSection.showPrices = v; })} hint="Turn off to hide all prices; customers will see “Price on request” and can ask on WhatsApp." />
              <Grid>
                <Text label="Small heading" value={c.productsSection.eyebrow} onChange={v => upd(d => { d.productsSection.eyebrow = v; })} />
                <Text label="Heading" value={c.productsSection.heading} onChange={v => upd(d => { d.productsSection.heading = v; })} />
                <Text label="“View all” button text" value={c.productsSection.buttonLabel} onChange={v => upd(d => { d.productsSection.buttonLabel = v; })} />
                <Text label="Products page heading" value={c.productsSection.pageHeading} onChange={v => upd(d => { d.productsSection.pageHeading = v; })} />
                <Text label="WhatsApp enquiry button text" value={c.productsSection.enquiryLabel} onChange={v => upd(d => { d.productsSection.enquiryLabel = v; })} />
                <label className="se-field">Products shown on home page<input type="number" min="1" max="12" value={c.productsSection.homeCount} onChange={e => upd(d => { d.productsSection.homeCount = Number(e.target.value) || 4; })} /><small>Products marked “Show on home page” are shown first.</small></label>
              </Grid>
            </>}

            {tab === 'about' && <>
              <ImageField label="About image" value={c.about.image} setError={setError} onChange={v => upd(d => { d.about.image = v; })} />
              <Grid><Text label="Small heading" value={c.about.eyebrow} onChange={v => upd(d => { d.about.eyebrow = v; })} /><Text label="Heading" value={c.about.heading} onChange={v => upd(d => { d.about.heading = v; })} /></Grid>
              <h3>Paragraphs</h3>
              {c.about.paragraphs.map((t, i) => (
                <Row key={i} onUp={() => upd(d => { d.about.paragraphs = move(d.about.paragraphs, i, -1); })} onDown={() => upd(d => { d.about.paragraphs = move(d.about.paragraphs, i, 1); })} onDelete={() => upd(d => { d.about.paragraphs.splice(i, 1); })}>
                  <Text label={`Paragraph ${i + 1}`} rows={3} value={t} onChange={v => upd(d => { d.about.paragraphs[i] = v; })} />
                </Row>
              ))}
              <AddButton onClick={() => upd(d => { d.about.paragraphs.push(''); })}>Add paragraph</AddButton>
              <h3>Highlights (tick list)</h3>
              {c.about.points.map((t, i) => (
                <Row key={i} onUp={() => upd(d => { d.about.points = move(d.about.points, i, -1); })} onDown={() => upd(d => { d.about.points = move(d.about.points, i, 1); })} onDelete={() => upd(d => { d.about.points.splice(i, 1); })}>
                  <Text label={`Point ${i + 1}`} value={t} onChange={v => upd(d => { d.about.points[i] = v; })} />
                </Row>
              ))}
              <AddButton onClick={() => upd(d => { d.about.points.push(''); })}>Add highlight</AddButton>
            </>}

            {tab === 'services' && <>
              <Grid><Text label="Small heading" value={c.services.eyebrow} onChange={v => upd(d => { d.services.eyebrow = v; })} /><Text label="Heading" value={c.services.heading} onChange={v => upd(d => { d.services.heading = v; })} /></Grid>
              {c.services.items.map((s, i) => (
                <Row key={s.id} onUp={() => upd(d => { d.services.items = move(d.services.items, i, -1); })} onDown={() => upd(d => { d.services.items = move(d.services.items, i, 1); })} onDelete={() => upd(d => { d.services.items.splice(i, 1); })}>
                  <Grid><IconSelect value={s.icon} onChange={v => upd(d => { d.services.items[i].icon = v; })} /><Text label="Service name" value={s.title} onChange={v => upd(d => { d.services.items[i].title = v; })} /></Grid>
                  <Text label="Description" rows={2} value={s.text} onChange={v => upd(d => { d.services.items[i].text = v; })} />
                </Row>
              ))}
              <AddButton onClick={() => upd(d => { d.services.items.push({id: newId(), icon: 'star', title: 'New service', text: ''}); })}>Add service</AddButton>
            </>}

            {tab === 'projects' && <>
              <Grid><Text label="Small heading" value={c.projects.eyebrow} onChange={v => upd(d => { d.projects.eyebrow = v; })} /><Text label="Heading" value={c.projects.heading} onChange={v => upd(d => { d.projects.heading = v; })} /></Grid>
              <p className="se-help">Add your completed installation projects with a photo, name and location.</p>
              {c.projects.items.map((p, i) => (
                <Row key={p.id} onUp={() => upd(d => { d.projects.items = move(d.projects.items, i, -1); })} onDown={() => upd(d => { d.projects.items = move(d.projects.items, i, 1); })} onDelete={() => upd(d => { d.projects.items.splice(i, 1); })}>
                  <ImageField label="Project photo" value={p.image} setError={setError} onChange={v => upd(d => { d.projects.items[i].image = v; })} />
                  <Grid><Text label="Project name" value={p.title} onChange={v => upd(d => { d.projects.items[i].title = v; })} /><Text label="Location" value={p.location} onChange={v => upd(d => { d.projects.items[i].location = v; })} /></Grid>
                  <Text label="Details" rows={2} value={p.text} onChange={v => upd(d => { d.projects.items[i].text = v; })} />
                </Row>
              ))}
              <AddButton onClick={() => upd(d => { d.projects.items.push({id: newId(), title: 'New project', location: '', text: '', image: ''}); })}>Add project</AddButton>
            </>}

            {tab === 'gallery' && <>
              <Grid><Text label="Small heading" value={c.gallery.eyebrow} onChange={v => upd(d => { d.gallery.eyebrow = v; })} /><Text label="Heading" value={c.gallery.heading} onChange={v => upd(d => { d.gallery.heading = v; })} /></Grid>
              <input ref={galleryRef} type="file" multiple hidden accept="image/jpeg,image/png,image/webp,image/avif" onChange={addGalleryImages} />
              <button type="button" className="btn btn-primary" disabled={uploading} onClick={() => galleryRef.current.click()}>{uploading ? <Loader2 size={15} className="spin" /> : <UploadCloud size={15} />}Upload gallery photos</button>
              <div className="se-gallery">
                {c.gallery.images.map((g, i) => (
                  <div className="se-gal" key={g.id}>
                    <img src={g.url} alt="" />
                    <input value={g.caption ?? ''} placeholder="Caption (optional)" onChange={e => upd(d => { d.gallery.images[i].caption = e.target.value; })} />
                    <div className="se-gal-tools">
                      <button type="button" onClick={() => upd(d => { d.gallery.images = move(d.gallery.images, i, -1); })} title="Move earlier"><ArrowUp size={14} /></button>
                      <button type="button" onClick={() => upd(d => { d.gallery.images = move(d.gallery.images, i, 1); })} title="Move later"><ArrowDown size={14} /></button>
                      <button type="button" className="danger" onClick={() => upd(d => { d.gallery.images.splice(i, 1); })} title="Delete"><Trash2 size={14} /></button>
                    </div>
                  </div>
                ))}
              </div>
              {!c.gallery.images.length && <p className="se-help">No photos yet. The Gallery section stays hidden until you add some.</p>}
            </>}

            {tab === 'contact' && <>
              <Grid><Text label="Small heading" value={c.contact.eyebrow} onChange={v => upd(d => { d.contact.eyebrow = v; })} /><Text label="Heading" value={c.contact.heading} onChange={v => upd(d => { d.contact.heading = v; })} /></Grid>
              <Text label="Intro text" rows={2} value={c.contact.text} onChange={v => upd(d => { d.contact.text = v; })} />
              <Text label="Shop address" rows={2} value={c.contact.address} onChange={v => upd(d => { d.contact.address = v; })} />
              <Text label="Google Maps link (optional)" value={c.contact.mapUrl} onChange={v => upd(d => { d.contact.mapUrl = v; })} hint="Leave empty to search the address automatically." />
              <h3>Phone numbers</h3>
              {c.contact.phones.map((ph, i) => (
                <Row key={i} onUp={() => upd(d => { d.contact.phones = move(d.contact.phones, i, -1); })} onDown={() => upd(d => { d.contact.phones = move(d.contact.phones, i, 1); })} onDelete={() => upd(d => { d.contact.phones.splice(i, 1); })}>
                  <Text label={`Phone ${i + 1}`} value={ph} onChange={v => upd(d => { d.contact.phones[i] = v; })} />
                </Row>
              ))}
              <AddButton onClick={() => upd(d => { d.contact.phones.push(''); })}>Add phone number</AddButton>
              <Grid>
                <Text label="WhatsApp number (with country code)" value={c.contact.whatsapp} onChange={v => upd(d => { d.contact.whatsapp = v.replace(/[^\d]/g, ''); })} hint="Example: 919527929796. All WhatsApp buttons use this number." />
                <Text label="Email (optional)" value={c.contact.email} onChange={v => upd(d => { d.contact.email = v; })} />
              </Grid>
              <h3>Social media &amp; footer</h3>
              <Grid>
                <Text label="Instagram link" value={c.social.instagram} onChange={v => upd(d => { d.social.instagram = v; })} placeholder="https://instagram.com/..." />
                <Text label="Facebook link" value={c.social.facebook} onChange={v => upd(d => { d.social.facebook = v; })} placeholder="https://facebook.com/..." />
                <Text label="YouTube link" value={c.social.youtube} onChange={v => upd(d => { d.social.youtube = v; })} placeholder="https://youtube.com/..." />
                <Text label="Footer tagline" value={c.footer.tagline} onChange={v => upd(d => { d.footer.tagline = v; })} />
              </Grid>
              <p className="se-help">Social icons appear in the footer once you add a link.</p>
            </>}

            {tab === 'theme' && <>
              <label className="se-field">Gold accent colour
                <div className="se-color"><input type="color" value={c.theme.gold} onChange={e => upd(d => { d.theme.gold = e.target.value; })} /><code>{c.theme.gold}</code>
                  {['#d8b05a', '#c9a24a', '#e0b95e', '#b8860b', '#e5c36b'].map(col => <button type="button" key={col} className="se-swatch" style={{background: col}} onClick={() => upd(d => { d.theme.gold = col; })} aria-label={col} />)}
                </div>
              </label>
            </>}

          </section>
        </div>
        {preview && <aside className="se-preview"><iframe key={previewKey} src="/" title="Website preview" /></aside>}
      </div>
    </div>
  );
}
