import React, {useState} from 'react';
import {ArrowRight, ShieldCheck} from 'lucide-react';
import {api, TOKEN_KEY, Brand} from '../common';
import '../admin.css';

export default function AdminLogin(){const [password,setPassword]=useState('');const [error,setError]=useState('');const [loading,setLoading]=useState(false);
  async function login(e){e.preventDefault();setError('');setLoading(true);try{const result=await api('/login',{method:'POST',body:JSON.stringify({password})});localStorage.setItem(TOKEN_KEY,result.token);location.href='/admin/dashboard';}catch(err){setError(err.message);}finally{setLoading(false)}}
  return <div className="login-page"><a href="/" className="back-home">← Back to website</a><div className="login-card"><Brand/><div className="eyebrow dark">PRIVATE MANAGEMENT PORTAL</div><h1>Admin <em>sign in.</em></h1><p>Authorised Galaxy PVC Panels administrators only.</p><form onSubmit={login}><label>Admin password<input type="password" required autoFocus value={password} onChange={e=>setPassword(e.target.value)} placeholder="Enter admin password" autoComplete="current-password"/></label>{error&&<div className="error">{error}</div>}<button className="btn btn-primary full" disabled={loading}>{loading?'Checking access...':'Secure sign in'} <ArrowRight size={16}/></button></form><small className="secure-note"><ShieldCheck size={14}/> Password-only admin access · No email required</small></div></div>;
}

