import React from 'react';

export const money = value => `₹${Number(value || 0).toLocaleString('en-IN',{maximumFractionDigits:2})}`;
export const today = () => {const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};
export const monthNow = () => today().slice(0,7);
export const TOKEN_KEY = 'galaxy_admin_token';

export async function api(path, options={}) {
  const headers = {...(options.headers||{})};
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) headers.Authorization = `Bearer ${token}`;
  if (options.body && !(options.body instanceof FormData)) headers['Content-Type'] = 'application/json';
  const response = await fetch(`/api${path}`, {...options, headers});
  const type = response.headers.get('content-type') || '';
  const payload = type.includes('application/json') ? await response.json() : await response.text();
  if (!response.ok) throw new Error(payload?.error || payload || `Request failed (${response.status})`);
  return payload;
}
export function downloadBase64(base64, filename) {
  const bytes = Uint8Array.from(atob(base64), c => c.charCodeAt(0));
  const url = URL.createObjectURL(new Blob([bytes], {type:'application/pdf'}));
  const a = document.createElement('a'); a.href=url; a.download=filename; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1500);
}
export async function downloadStoredPdf(path, filename) {
  const token=localStorage.getItem(TOKEN_KEY);const response=await fetch(`/api${path}`,{headers:{Authorization:`Bearer ${token}`}});
  if(!response.ok)throw new Error('Could not retrieve the saved PDF.');const blob=await response.blob();const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);
}
export function Brand({src='/assets/galaxy-logo.png'}){return <a href="/" className="brand" aria-label="Galaxy PVC Panels home"><img className="brand-logo" src={src} alt="Galaxy PVC Panel logo"/></a>}
